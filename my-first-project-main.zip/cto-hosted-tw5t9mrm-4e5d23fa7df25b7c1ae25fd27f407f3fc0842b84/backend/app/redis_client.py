import redis.asyncio as aioredis
from app.config import settings
import logging

logger = logging.getLogger(__name__)

_redis_client = None


async def get_redis():
    global _redis_client
    if _redis_client is None:
        try:
            _redis_client = await aioredis.from_url(
                settings.REDIS_URL,
                encoding="utf-8",
                decode_responses=True,
                max_connections=50,
            )
            await _redis_client.ping()
            logger.info("Redis connected")
        except Exception as e:
            logger.warning(f"Redis unavailable: {e} — using in-memory fallback")
            _redis_client = InMemoryCache()
    return _redis_client


async def close_redis():
    global _redis_client
    if _redis_client and hasattr(_redis_client, "aclose"):
        await _redis_client.aclose()
        _redis_client = None


class InMemoryCache:
    """Fallback in-memory cache when Redis is unavailable."""

    def __init__(self):
        self._store: dict = {}
        self._ttl: dict = {}

    async def get(self, key: str):
        import time
        if key in self._ttl and time.time() > self._ttl[key]:
            self._store.pop(key, None)
            self._ttl.pop(key, None)
            return None
        return self._store.get(key)

    async def set(self, key: str, value, ex: int = None):
        import time
        self._store[key] = value
        if ex:
            self._ttl[key] = time.time() + ex

    async def delete(self, key: str):
        self._store.pop(key, None)
        self._ttl.pop(key, None)

    async def ping(self):
        return True
