from fastapi import WebSocket
import json
import logging

logger = logging.getLogger(__name__)


class ConnectionManager:
    def __init__(self):
        self.active_connections: dict[str, list[WebSocket]] = {}
        self.all_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept()
        if user_id not in self.active_connections:
            self.active_connections[user_id] = []
        self.active_connections[user_id].append(websocket)
        if websocket not in self.all_connections:
            self.all_connections.append(websocket)
        logger.info(f"WS connected: user={user_id}, total={len(self.all_connections)}")

    def disconnect(self, websocket: WebSocket, user_id: str):
        if user_id in self.active_connections:
            try:
                self.active_connections[user_id].remove(websocket)
            except ValueError:
                pass
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]
        try:
            self.all_connections.remove(websocket)
        except ValueError:
            pass
        logger.info(f"WS disconnected: user={user_id}, total={len(self.all_connections)}")

    async def broadcast(self, message: dict):
        data = json.dumps(message, default=str)
        dead = []
        for ws in self.all_connections:
            try:
                await ws.send_text(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            try:
                self.all_connections.remove(ws)
            except ValueError:
                pass

    async def send_to_user(self, user_id: str, message: dict):
        if user_id not in self.active_connections:
            return
        data = json.dumps(message, default=str)
        dead = []
        for ws in self.active_connections[user_id]:
            try:
                await ws.send_text(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            try:
                self.active_connections[user_id].remove(ws)
            except ValueError:
                pass

    @property
    def connection_count(self) -> int:
        return len(self.all_connections)


manager = ConnectionManager()
