from pydantic import BaseModel
from datetime import datetime


class PortfolioSummary(BaseModel):
    virtual_capital: float
    total_value: float
    total_pnl: float
    total_pnl_pct: float
    open_trades: int
    closed_trades: int
    win_rate: float
    used_capital: float
    available_capital: float


class PortfolioSnapshotResponse(BaseModel):
    id: str
    total_value: float
    total_pnl: float
    total_pnl_pct: float
    open_trades: int
    snapshot_at: datetime

    model_config = {"from_attributes": True}


class PortfolioChartResponse(BaseModel):
    snapshots: list[PortfolioSnapshotResponse]
    period: str
