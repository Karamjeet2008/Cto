from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class SignalResponse(BaseModel):
    id: str
    instrument: str
    display_name: str
    segment: str
    signal_type: str
    entry_price: float
    stop_loss: float
    target1: float
    target2: float
    confidence_score: float
    risk_reward_ratio: float
    ai_reasoning: Optional[str] = None
    technical_score: float
    sentiment_score: float
    quant_score: float
    options_score: float
    status: str
    expires_at: Optional[datetime] = None
    backtest_win_rate: float
    backtest_sample_size: int
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class SignalListResponse(BaseModel):
    signals: list[SignalResponse]
    total: int
    active_count: int


class SignalFilterParams(BaseModel):
    segment: Optional[str] = None
    signal_type: Optional[str] = None
    status: Optional[str] = "active"
    min_confidence: Optional[float] = 0.0
    limit: int = 50
    offset: int = 0


class SignalAccuracyStats(BaseModel):
    total_signals: int
    win_count: int
    loss_count: int
    expired_count: int
    win_rate: float
    avg_confidence: float
    avg_rr_ratio: float
    by_segment: dict
