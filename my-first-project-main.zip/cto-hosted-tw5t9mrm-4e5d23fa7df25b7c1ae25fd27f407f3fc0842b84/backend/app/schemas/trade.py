from pydantic import BaseModel, field_validator
from typing import Optional
from datetime import datetime


class TakeTradeRequest(BaseModel):
    signal_id: str
    quantity: float

    @field_validator("quantity")
    @classmethod
    def positive_quantity(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("Quantity must be positive")
        return v


class TradeResponse(BaseModel):
    id: str
    user_id: str
    signal_id: str
    quantity: float
    entry_price: float
    exit_price: Optional[float] = None
    current_price: float
    pnl: float
    pnl_pct: float
    status: str
    exit_reason: Optional[str] = None
    opened_at: datetime
    closed_at: Optional[datetime] = None
    signal: Optional[dict] = None

    model_config = {"from_attributes": True}


class TradeListResponse(BaseModel):
    trades: list[TradeResponse]
    total: int
    open_count: int
    total_pnl: float
