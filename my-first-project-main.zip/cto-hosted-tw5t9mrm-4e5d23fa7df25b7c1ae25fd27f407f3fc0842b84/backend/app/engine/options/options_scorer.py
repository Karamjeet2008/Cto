from .pcr_analyzer import PCRAnalyzer


class OptionsScorer:

    def __init__(self):
        self.pcr = PCRAnalyzer()

    def score(self, oi_data: dict) -> dict:
        return self.pcr.analyze(oi_data)
