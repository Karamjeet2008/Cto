import logging

logger = logging.getLogger(__name__)


class PCRAnalyzer:
    """
    Put-Call Ratio (PCR) analysis from NSE OI data.
    PCR > 1.2: Bullish (more puts = market expects support)
    PCR < 0.8: Bearish (more calls = market expects resistance)
    """

    def analyze(self, oi_data: dict) -> dict:
        if not oi_data:
            return {"score": 0.0, "pcr": None}

        try:
            total_call_oi = oi_data.get("total_call_oi", 0)
            total_put_oi = oi_data.get("total_put_oi", 0)

            if total_call_oi == 0:
                return {"score": 0.0, "pcr": None}

            pcr = total_put_oi / total_call_oi

            if pcr > 1.5:
                score = 1.0
            elif pcr > 1.2:
                score = 0.7
            elif pcr > 0.9:
                score = 0.2
            elif pcr > 0.7:
                score = -0.4
            else:
                score = -0.8

            return {
                "score": float(score),
                "pcr": round(pcr, 2),
                "total_call_oi": total_call_oi,
                "total_put_oi": total_put_oi,
                "call_resistance": oi_data.get("call_resistance"),
                "put_support": oi_data.get("put_support"),
                "interpretation": self._interpret(pcr),
            }
        except Exception as e:
            logger.error(f"PCR analysis error: {e}")
            return {"score": 0.0, "pcr": None}

    def _interpret(self, pcr: float) -> str:
        if pcr > 1.5:
            return "Extremely Bullish — Heavy put writing indicates strong support"
        elif pcr > 1.2:
            return "Bullish — Market expects upside"
        elif pcr > 0.9:
            return "Neutral — Balanced options positioning"
        elif pcr > 0.7:
            return "Mildly Bearish — Call writing suggests overhead resistance"
        else:
            return "Bearish — Heavy call writing indicates strong resistance"
