import pandas as pd
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class SignalGenerator:
    """
    Builds a complete signal dict from fused analysis results and price data.
    Computes ATR-based entry/SL/targets and generates AI reasoning explanation.
    """

    def build_signal(
        self,
        instrument: dict,
        fusion_result: dict,
        df: pd.DataFrame,
        levels: dict,
        atr_value: float,
    ) -> dict:
        current_price = float(df["Close"].iloc[-1])
        signal_type = fusion_result["signal_type"]
        confidence = fusion_result["confidence_score"]

        atr = atr_value if atr_value and atr_value > 0 else current_price * 0.015

        if signal_type == "BUY":
            entry = current_price
            nearest_support = levels.get("nearest_support")
            if nearest_support and nearest_support < entry:
                sl_from_support = nearest_support * 0.998
                sl_from_atr = entry - atr * 2.0
                sl = max(sl_from_support, sl_from_atr)
            else:
                sl = entry - atr * 2.0
            t1 = entry + atr * 1.5
            t2 = entry + atr * 3.0
        else:
            entry = current_price
            nearest_resistance = levels.get("nearest_resistance")
            if nearest_resistance and nearest_resistance > entry:
                sl_from_resistance = nearest_resistance * 1.002
                sl_from_atr = entry + atr * 2.0
                sl = min(sl_from_resistance, sl_from_atr)
            else:
                sl = entry + atr * 2.0
            t1 = entry - atr * 1.5
            t2 = entry - atr * 3.0

        risk = abs(entry - sl)
        reward1 = abs(t1 - entry)
        rr_ratio = round(reward1 / risk, 2) if risk > 0 else 1.0

        expires_at = self._compute_expiry(instrument["segment"])
        reasoning = self._build_reasoning(fusion_result, levels, instrument, atr)

        return {
            "instrument": instrument["symbol"],
            "display_name": instrument["display"],
            "segment": instrument["segment"],
            "signal_type": signal_type,
            "entry_price": round(entry, 2),
            "stop_loss": round(sl, 2),
            "target1": round(t1, 2),
            "target2": round(t2, 2),
            "confidence_score": confidence,
            "risk_reward_ratio": rr_ratio,
            "ai_reasoning": reasoning,
            "technical_score": fusion_result["layer_scores"]["technical"],
            "sentiment_score": fusion_result["layer_scores"]["sentiment"],
            "quant_score": fusion_result["layer_scores"]["quantitative"],
            "options_score": fusion_result["layer_scores"]["options"],
            "expires_at": expires_at,
        }

    def _compute_expiry(self, segment: str) -> datetime:
        now = datetime.utcnow()
        if segment in ["fo"]:
            from datetime import timezone
            import pytz
            ist = pytz.timezone("Asia/Kolkata")
            ist_now = datetime.now(ist)
            market_close = ist_now.replace(hour=15, minute=30, second=0, microsecond=0)
            if ist_now > market_close:
                market_close += timedelta(days=1)
            return market_close.astimezone(pytz.utc).replace(tzinfo=None)
        else:
            return now + timedelta(days=5)

    def _build_reasoning(
        self,
        fusion: dict,
        levels: dict,
        instrument: dict,
        atr: float,
    ) -> str:
        ls = fusion["layer_scores"]
        signal_type = fusion["signal_type"]
        direction = "bullish" if signal_type == "BUY" else "bearish"
        parts = []

        if abs(ls["technical"]) > 35:
            strength = "strongly" if abs(ls["technical"]) > 60 else "moderately"
            parts.append(f"Technical indicators are {strength} {direction} (TA score: {ls['technical']:+.0f})")

        if abs(ls["quantitative"]) > 25:
            mom_dir = "upward" if ls["quantitative"] > 0 else "downward"
            parts.append(f"Quantitative models confirm {mom_dir} momentum (score: {ls['quantitative']:+.0f})")

        if abs(ls["sentiment"]) > 20:
            sentiment = "positive" if ls["sentiment"] > 0 else "negative"
            parts.append(f"Market sentiment from recent news is {sentiment} (score: {ls['sentiment']:+.0f})")

        if ls["options"] and abs(ls["options"]) > 25:
            opt_dir = "buying" if ls["options"] > 0 else "selling"
            parts.append(f"Options flow (PCR analysis) suggests {opt_dir} pressure")

        if levels.get("nearest_support"):
            parts.append(f"Key support at ₹{levels['nearest_support']:,.2f}")
        if levels.get("nearest_resistance"):
            parts.append(f"Key resistance at ₹{levels['nearest_resistance']:,.2f}")

        if not parts:
            parts.append(f"Multi-layer AI confluence {direction} signal on {instrument['display']}")

        return " • ".join(parts)
