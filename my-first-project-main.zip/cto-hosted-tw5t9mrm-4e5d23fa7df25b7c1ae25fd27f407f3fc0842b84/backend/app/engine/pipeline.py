import asyncio
import logging
from .data.data_aggregator import DataAggregator
from .instruments import get_all_instruments
from .technical.ta_scorer import TAScorer
from .technical.indicators import TechnicalIndicators
from .sentiment.news_fetcher import NewsFetcher
from .sentiment.sentiment_scorer import SentimentScorer
from .quantitative.quant_scorer import QuantScorer
from .options.options_scorer import OptionsScorer
from .fusion.signal_fusion import SignalFusion
from .signal_generator import SignalGenerator
from .backtesting.backtester import Backtester
from app.config import settings

logger = logging.getLogger(__name__)


class SignalPipeline:

    def __init__(self, data_aggregator: DataAggregator):
        self.data = data_aggregator
        self.ta_scorer = TAScorer()
        self.news_fetcher = NewsFetcher()
        self.sentiment_scorer = SentimentScorer()
        self.quant_scorer = QuantScorer()
        self.options_scorer = OptionsScorer()
        self.fusion = SignalFusion()
        self.signal_gen = SignalGenerator()
        self.backtester = Backtester()

    async def run_for_instrument(self, instrument: dict) -> dict | None:
        symbol = instrument["symbol"]
        segment = instrument["segment"]

        try:
            df_daily = await self.data.get_ohlcv(symbol, period="6mo", interval="1d")
            if df_daily is None or len(df_daily) < 30:
                logger.debug(f"Insufficient data for {symbol}: {len(df_daily) if df_daily is not None else 0} candles")
                return None

            ta_result = self.ta_scorer.compute(df_daily)

            atr_series = TechnicalIndicators.atr(df_daily)
            atr_clean = atr_series.dropna()
            atr_value = float(atr_clean.iloc[-1]) if not atr_clean.empty else float(df_daily["Close"].iloc[-1]) * 0.015

            articles = await self.news_fetcher.fetch_for_instrument(instrument["display"])
            sentiment_result = self.sentiment_scorer.score(articles)

            quant_result = self.quant_scorer.score(df_daily)

            options_result = {"score": 0.0}
            if segment == "fo":
                nse_symbol = instrument.get("nse_symbol", "NIFTY")
                oi_data = await self.data.get_oi_data(nse_symbol)
                options_result = self.options_scorer.score(oi_data)

            fusion_result = self.fusion.fuse(
                ta_result,
                sentiment_result,
                quant_result,
                options_result,
                segment,
                min_confidence=settings.MIN_CONFIDENCE_THRESHOLD,
            )

            if not fusion_result["is_publishable"]:
                logger.debug(f"Signal below confidence threshold for {symbol}: {fusion_result['confidence_score']:.1f}%")
                return None

            signal = self.signal_gen.build_signal(
                instrument,
                fusion_result,
                df_daily,
                ta_result.get("levels", {}),
                atr_value,
            )

            backtest = self.backtester.run(
                df_daily,
                signal["signal_type"],
                signal["entry_price"],
                signal["stop_loss"],
                signal["target1"],
                signal["target2"],
            )
            signal["backtest_win_rate"] = backtest["win_rate"]
            signal["backtest_sample_size"] = backtest["sample_size"]

            logger.info(
                f"Signal generated: {symbol} {signal['signal_type']} "
                f"confidence={signal['confidence_score']}% "
                f"backtest_win_rate={signal['backtest_win_rate']}%"
            )
            return signal

        except Exception as e:
            logger.error(f"Pipeline failed for {symbol}: {e}", exc_info=True)
            return None

    async def run_all(self, max_concurrent: int = 5) -> list[dict]:
        instruments = get_all_instruments()
        results = []
        semaphore = asyncio.Semaphore(max_concurrent)

        async def run_with_semaphore(inst: dict) -> dict | None:
            async with semaphore:
                result = await self.run_for_instrument(inst)
                await asyncio.sleep(0.5)
                return result

        tasks = [run_with_semaphore(inst) for inst in instruments]
        batch_results = await asyncio.gather(*tasks, return_exceptions=True)

        for r in batch_results:
            if isinstance(r, Exception):
                logger.error(f"Batch pipeline error: {r}")
            elif r is not None:
                results.append(r)

        logger.info(f"Pipeline complete: {len(results)} signals generated from {len(instruments)} instruments")
        return results
