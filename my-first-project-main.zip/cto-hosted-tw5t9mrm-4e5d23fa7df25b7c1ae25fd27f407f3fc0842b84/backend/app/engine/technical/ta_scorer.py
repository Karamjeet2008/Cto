import numpy as np
import pandas as pd
import logging
from .indicators import TechnicalIndicators
from .patterns import CandlestickPatterns
from .support_resistance import SupportResistance

logger = logging.getLogger(__name__)


class TAScorer:
    """
    Aggregates all technical indicators into a single score: -1 to +1
    Positive = BUY signal, Negative = SELL signal, Magnitude = confidence
    """

    WEIGHTS = {
        "rsi": 0.15,
        "macd": 0.20,
        "bollinger": 0.12,
        "ema_crossover": 0.18,
        "volume": 0.10,
        "candlestick": 0.12,
        "support_resistance": 0.13,
    }

    def compute(self, df: pd.DataFrame) -> dict:
        if len(df) < 30:
            return {"score": 0.0, "score_100": 0.0, "components": {}, "levels": {}}

        scores = {}
        levels = {}

        try:
            rsi_series = TechnicalIndicators.rsi(df)
            rsi_val = float(rsi_series.dropna().iloc[-1]) if not rsi_series.dropna().empty else 50.0
            if rsi_val < 30:
                scores["rsi"] = (30 - rsi_val) / 30
            elif rsi_val > 70:
                scores["rsi"] = -(rsi_val - 70) / 30
            else:
                scores["rsi"] = (50 - rsi_val) / 50 * 0.3
        except Exception as e:
            logger.debug(f"RSI error: {e}")
            scores["rsi"] = 0.0

        try:
            macd_line, histogram, signal_line = TechnicalIndicators.macd(df)
            hist_clean = histogram.dropna()
            if len(hist_clean) >= 2:
                hist_now = float(hist_clean.iloc[-1])
                hist_prev = float(hist_clean.iloc[-2])
                if hist_now > 0 and hist_prev <= 0:
                    scores["macd"] = 1.0
                elif hist_now < 0 and hist_prev >= 0:
                    scores["macd"] = -1.0
                else:
                    scores["macd"] = float(np.clip(hist_now / (abs(hist_now) + 0.001) * 0.5, -1, 1))
            else:
                scores["macd"] = 0.0
        except Exception as e:
            logger.debug(f"MACD error: {e}")
            scores["macd"] = 0.0

        try:
            upper, mid, lower = TechnicalIndicators.bollinger_bands(df)
            close = float(df["Close"].iloc[-1])
            upper_val = float(upper.dropna().iloc[-1]) if not upper.dropna().empty else close * 1.02
            lower_val = float(lower.dropna().iloc[-1]) if not lower.dropna().empty else close * 0.98
            bw = upper_val - lower_val
            if bw > 0:
                pos = (close - lower_val) / bw
                scores["bollinger"] = float((0.5 - pos) * 2)
            else:
                scores["bollinger"] = 0.0
        except Exception as e:
            logger.debug(f"Bollinger error: {e}")
            scores["bollinger"] = 0.0

        try:
            emas = TechnicalIndicators.ema(df, [9, 21, 50, 200])
            e9 = emas[9].dropna()
            e21 = emas[21].dropna()
            if len(e9) >= 2 and len(e21) >= 2:
                e9_now = float(e9.iloc[-1])
                e21_now = float(e21.iloc[-1])
                e9_prev = float(e9.iloc[-2])
                e21_prev = float(e21.iloc[-2])
                if e9_now > e21_now and e9_prev <= e21_prev:
                    scores["ema_crossover"] = 1.0
                elif e9_now < e21_now and e9_prev >= e21_prev:
                    scores["ema_crossover"] = -1.0
                elif e9_now > e21_now:
                    scores["ema_crossover"] = 0.4
                else:
                    scores["ema_crossover"] = -0.4
            else:
                scores["ema_crossover"] = 0.0
        except Exception as e:
            logger.debug(f"EMA error: {e}")
            scores["ema_crossover"] = 0.0

        try:
            vol_data = TechnicalIndicators.volume_analysis(df)
            vr_series = vol_data["volume_ratio"].dropna()
            vr = float(vr_series.iloc[-1]) if not vr_series.empty else 1.0
            close_chg = float(df["Close"].iloc[-1]) - float(df["Close"].iloc[-2])
            if vr > 1.5 and close_chg > 0:
                scores["volume"] = 0.8
            elif vr > 1.5 and close_chg < 0:
                scores["volume"] = -0.8
            elif vr > 1.2:
                scores["volume"] = 0.3 if close_chg > 0 else -0.3
            else:
                scores["volume"] = 0.0
        except Exception as e:
            logger.debug(f"Volume error: {e}")
            scores["volume"] = 0.0

        try:
            patterns = CandlestickPatterns.detect(df)
            scores["candlestick"] = CandlestickPatterns.net_pattern_signal(patterns)
        except Exception as e:
            logger.debug(f"Candlestick error: {e}")
            scores["candlestick"] = 0.0

        try:
            levels = SupportResistance.find_levels(df)
            close = float(df["Close"].iloc[-1])
            sup = levels.get("nearest_support")
            res = levels.get("nearest_resistance")
            if sup and res:
                scores["support_resistance"] = SupportResistance.proximity_score(close, sup, res)
            else:
                scores["support_resistance"] = 0.0
        except Exception as e:
            logger.debug(f"S/R error: {e}")
            scores["support_resistance"] = 0.0
            levels = {}

        total = sum(self.WEIGHTS.get(k, 0) * scores.get(k, 0) for k in self.WEIGHTS)
        total = float(np.clip(total, -1.0, 1.0))

        return {
            "score": total,
            "score_100": round(total * 100, 1),
            "components": scores,
            "levels": levels,
        }
