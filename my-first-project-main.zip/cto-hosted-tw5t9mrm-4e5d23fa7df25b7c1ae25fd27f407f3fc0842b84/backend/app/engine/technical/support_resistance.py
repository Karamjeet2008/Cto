import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class SupportResistance:

    @staticmethod
    def find_levels(df: pd.DataFrame, order: int = 5) -> dict:
        if len(df) < order * 3:
            current = float(df["Close"].iloc[-1])
            return {
                "nearest_resistance": current * 1.03,
                "nearest_support": current * 0.97,
                "all_resistance": [current * 1.03],
                "all_support": [current * 0.97],
            }

        try:
            from scipy.signal import argrelextrema
            highs = df["High"].values
            lows = df["Low"].values

            resistance_idx = argrelextrema(highs, np.greater, order=order)[0]
            support_idx = argrelextrema(lows, np.less, order=order)[0]

            resistance_levels = sorted(
                set(np.round(highs[resistance_idx], 2).tolist()),
                reverse=True,
            )
            support_levels = sorted(
                set(np.round(lows[support_idx], 2).tolist()),
                reverse=True,
            )

            current = float(df["Close"].iloc[-1])

            nearest_res = next((r for r in resistance_levels if r > current), None)
            nearest_sup = next((s for s in support_levels if s < current), None)

            if not nearest_res:
                nearest_res = current * 1.03
            if not nearest_sup:
                nearest_sup = current * 0.97

            return {
                "nearest_resistance": nearest_res,
                "nearest_support": nearest_sup,
                "all_resistance": resistance_levels[:5],
                "all_support": support_levels[:5],
            }
        except Exception as e:
            logger.error(f"Support/Resistance error: {e}")
            current = float(df["Close"].iloc[-1])
            return {
                "nearest_resistance": current * 1.03,
                "nearest_support": current * 0.97,
                "all_resistance": [],
                "all_support": [],
            }

    @staticmethod
    def proximity_score(current: float, support: float, resistance: float) -> float:
        if not support or not resistance:
            return 0.0
        total_range = resistance - support
        if total_range <= 0:
            return 0.0
        position = (current - support) / total_range
        return float(np.clip((0.5 - position) * 2, -1.0, 1.0))
