import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__name__)


class TechnicalIndicators:

    @staticmethod
    def rsi(df: pd.DataFrame, period: int = 14) -> pd.Series:
        try:
            import pandas_ta as ta
            result = ta.rsi(df["Close"], length=period)
            return result if result is not None else pd.Series([50.0] * len(df), index=df.index)
        except Exception:
            delta = df["Close"].diff()
            gain = delta.where(delta > 0, 0).rolling(period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(period).mean()
            rs = gain / loss.replace(0, np.nan)
            return 100 - (100 / (1 + rs))

    @staticmethod
    def macd(df: pd.DataFrame) -> tuple[pd.Series, pd.Series, pd.Series]:
        try:
            import pandas_ta as ta
            macd_df = ta.macd(df["Close"])
            if macd_df is None or macd_df.empty:
                raise ValueError("MACD returned empty")
            cols = macd_df.columns.tolist()
            return macd_df[cols[0]], macd_df[cols[1]], macd_df[cols[2]]
        except Exception:
            ema12 = df["Close"].ewm(span=12).mean()
            ema26 = df["Close"].ewm(span=26).mean()
            macd_line = ema12 - ema26
            signal_line = macd_line.ewm(span=9).mean()
            histogram = macd_line - signal_line
            return macd_line, histogram, signal_line

    @staticmethod
    def bollinger_bands(df: pd.DataFrame, period: int = 20) -> tuple[pd.Series, pd.Series, pd.Series]:
        try:
            import pandas_ta as ta
            bb = ta.bbands(df["Close"], length=period)
            if bb is None or bb.empty:
                raise ValueError("BB returned empty")
            cols = bb.columns.tolist()
            upper = bb[[c for c in cols if c.startswith("BBU")][0]]
            mid = bb[[c for c in cols if c.startswith("BBM")][0]]
            lower = bb[[c for c in cols if c.startswith("BBL")][0]]
            return upper, mid, lower
        except Exception:
            mid = df["Close"].rolling(period).mean()
            std = df["Close"].rolling(period).std()
            return mid + 2 * std, mid, mid - 2 * std

    @staticmethod
    def ema(df: pd.DataFrame, periods: list[int] | None = None) -> dict[int, pd.Series]:
        if periods is None:
            periods = [9, 21, 50, 200]
        result = {}
        for p in periods:
            try:
                import pandas_ta as ta
                val = ta.ema(df["Close"], length=p)
                result[p] = val if val is not None else df["Close"].ewm(span=p).mean()
            except Exception:
                result[p] = df["Close"].ewm(span=p).mean()
        return result

    @staticmethod
    def volume_analysis(df: pd.DataFrame) -> dict:
        if "Volume" not in df.columns or df["Volume"].sum() == 0:
            return {"volume_ratio": pd.Series([1.0] * len(df), index=df.index), "avg_volume": pd.Series([0.0] * len(df), index=df.index)}
        avg_vol = df["Volume"].rolling(20).mean()
        vol_ratio = df["Volume"] / avg_vol.replace(0, np.nan)
        return {"volume_ratio": vol_ratio.fillna(1.0), "avg_volume": avg_vol}

    @staticmethod
    def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
        try:
            import pandas_ta as ta
            result = ta.atr(df["High"], df["Low"], df["Close"], length=period)
            return result if result is not None else pd.Series([df["Close"].iloc[-1] * 0.02] * len(df), index=df.index)
        except Exception:
            high_low = df["High"] - df["Low"]
            high_close = abs(df["High"] - df["Close"].shift())
            low_close = abs(df["Low"] - df["Close"].shift())
            tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
            return tr.rolling(period).mean()

    @staticmethod
    def stochastic(df: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
        try:
            import pandas_ta as ta
            stoch = ta.stoch(df["High"], df["Low"], df["Close"])
            if stoch is None or stoch.empty:
                raise ValueError("Stoch returned empty")
            cols = stoch.columns.tolist()
            return stoch[cols[0]], stoch[cols[1]]
        except Exception:
            low14 = df["Low"].rolling(14).min()
            high14 = df["High"].rolling(14).max()
            k = 100 * (df["Close"] - low14) / (high14 - low14 + 1e-9)
            d = k.rolling(3).mean()
            return k, d
