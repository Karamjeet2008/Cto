import pandas as pd
import logging

logger = logging.getLogger(__name__)

BULLISH_PATTERNS = [
    "CDL_DOJI_10_0.1",
    "CDL_HAMMER_10_1.5_1.0_1.0",
    "CDL_ENGULFING",
    "CDL_MORNINGSTAR",
    "CDL_PIERCING",
    "CDL_3WHITESOLDIERS",
    "CDL_INVERTEDHAMMER",
    "CDL_HARAMI",
    "CDL_DRAGONFLYDOJI_10",
]
BEARISH_PATTERNS = [
    "CDL_SHOOTINGSTAR_10_1.5_1.0_1.0",
    "CDL_HANGINGMAN_10_1.5_1.0_1.0",
    "CDL_DARKCLOUDCOVER",
    "CDL_3BLACKCROWS",
    "CDL_EVENINGSTAR",
    "CDL_GRAVESTONEDOJI_10",
]


class CandlestickPatterns:

    @staticmethod
    def detect(df: pd.DataFrame) -> dict:
        if len(df) < 5:
            return {}
        scores = {}
        try:
            import pandas_ta as ta
            cdl = ta.cdl_pattern(df["Open"], df["High"], df["Low"], df["Close"], name="all")
            if cdl is not None and not cdl.empty:
                for col in cdl.columns:
                    val = cdl[col].iloc[-1]
                    if pd.notna(val) and val != 0:
                        scores[col] = val
        except Exception as e:
            logger.debug(f"Candlestick pattern detection error: {e}")
        return scores

    @staticmethod
    def net_pattern_signal(patterns: dict) -> float:
        if not patterns:
            return 0.0
        bullish = sum(1 for v in patterns.values() if v > 0)
        bearish = sum(1 for v in patterns.values() if v < 0)
        total = bullish + bearish
        if total == 0:
            return 0.0
        return (bullish - bearish) / total
