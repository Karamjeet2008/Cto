import pandas as pd
import logging

logger = logging.getLogger(__name__)


class Backtester:
    """
    Walk-forward backtester that validates signal accuracy on historical data.
    Simulates: enter at signal price, check if T1/T2 hit before SL on subsequent candles.
    """

    def run(
        self,
        df: pd.DataFrame,
        signal_type: str,
        entry: float,
        sl: float,
        t1: float,
        t2: float,
        lookback: int = 60,
    ) -> dict:
        if len(df) < 20:
            return {"win_rate": 50.0, "sample_size": 0, "t1_hits": 0, "t2_hits": 0, "sl_hits": 0}

        wins_t1 = 0
        wins_t2 = 0
        losses = 0
        total_trades = 0
        pnl_pcts = []

        start_idx = max(1, len(df) - lookback)
        end_idx = len(df) - 5

        if start_idx >= end_idx:
            return {"win_rate": 50.0, "sample_size": 0, "t1_hits": 0, "t2_hits": 0, "sl_hits": 0}

        for i in range(start_idx, end_idx):
            sim_entry = float(df["Close"].iloc[i])
            if sim_entry <= 0:
                continue

            if signal_type == "BUY":
                risk = sim_entry - sl if sl < sim_entry else sim_entry * 0.02
                if risk <= 0:
                    continue
                sim_sl = sim_entry - risk
                sim_t1 = sim_entry + risk * 1.5
                sim_t2 = sim_entry + risk * 3.0
            else:
                risk = sl - sim_entry if sl > sim_entry else sim_entry * 0.02
                if risk <= 0:
                    continue
                sim_sl = sim_entry + risk
                sim_t1 = sim_entry - risk * 1.5
                sim_t2 = sim_entry - risk * 3.0

            hit_t2 = False
            hit_t1 = False
            hit_sl = False

            for j in range(i + 1, min(i + 20, len(df))):
                h = float(df["High"].iloc[j])
                l = float(df["Low"].iloc[j])

                if signal_type == "BUY":
                    if l <= sim_sl:
                        hit_sl = True
                        break
                    elif h >= sim_t2:
                        hit_t2 = True
                        break
                    elif h >= sim_t1:
                        hit_t1 = True
                else:
                    if h >= sim_sl:
                        hit_sl = True
                        break
                    elif l <= sim_t2:
                        hit_t2 = True
                        break
                    elif l <= sim_t1:
                        hit_t1 = True

            total_trades += 1
            if hit_t2:
                wins_t2 += 1
                pnl_pcts.append((sim_t2 - sim_entry) / sim_entry * 100 if signal_type == "BUY" else (sim_entry - sim_t2) / sim_entry * 100)
            elif hit_t1:
                wins_t1 += 1
                pnl_pcts.append((sim_t1 - sim_entry) / sim_entry * 100 if signal_type == "BUY" else (sim_entry - sim_t1) / sim_entry * 100)
            elif hit_sl:
                losses += 1
                pnl_pcts.append(-risk / sim_entry * 100)

        if total_trades == 0:
            return {"win_rate": 50.0, "sample_size": 0, "t1_hits": 0, "t2_hits": 0, "sl_hits": 0}

        win_rate = (wins_t1 + wins_t2) / total_trades * 100

        return {
            "win_rate": round(win_rate, 1),
            "sample_size": total_trades,
            "t1_hits": wins_t1,
            "t2_hits": wins_t2,
            "sl_hits": losses,
            "avg_pnl_pct": round(sum(pnl_pcts) / len(pnl_pcts), 2) if pnl_pcts else 0.0,
        }
