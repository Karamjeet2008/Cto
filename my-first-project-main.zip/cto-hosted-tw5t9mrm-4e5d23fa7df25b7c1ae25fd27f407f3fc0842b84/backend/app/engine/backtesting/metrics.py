import numpy as np


def compute_sharpe(returns: list[float], risk_free_rate: float = 0.07) -> float:
    if not returns or len(returns) < 2:
        return 0.0
    arr = np.array(returns)
    daily_rf = risk_free_rate / 252
    excess = arr - daily_rf
    std = np.std(excess)
    if std == 0:
        return 0.0
    return float(np.mean(excess) / std * np.sqrt(252))


def compute_max_drawdown(equity_curve: list[float]) -> float:
    if not equity_curve:
        return 0.0
    arr = np.array(equity_curve)
    peak = np.maximum.accumulate(arr)
    drawdown = (arr - peak) / peak
    return float(np.min(drawdown) * 100)


def compute_win_rate(wins: int, total: int) -> float:
    if total == 0:
        return 0.0
    return round(wins / total * 100, 1)


def compute_profit_factor(gross_profit: float, gross_loss: float) -> float:
    if gross_loss == 0:
        return float("inf") if gross_profit > 0 else 0.0
    return round(gross_profit / abs(gross_loss), 2)
