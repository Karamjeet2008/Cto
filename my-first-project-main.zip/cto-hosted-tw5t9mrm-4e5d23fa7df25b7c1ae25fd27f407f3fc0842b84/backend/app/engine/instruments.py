INSTRUMENTS: dict[str, list[dict]] = {
    "equity": [
        {"symbol": "RELIANCE.NS", "display": "Reliance Industries", "exchange": "NSE"},
        {"symbol": "TCS.NS", "display": "TCS", "exchange": "NSE"},
        {"symbol": "HDFCBANK.NS", "display": "HDFC Bank", "exchange": "NSE"},
        {"symbol": "INFY.NS", "display": "Infosys", "exchange": "NSE"},
        {"symbol": "ICICIBANK.NS", "display": "ICICI Bank", "exchange": "NSE"},
        {"symbol": "HINDUNILVR.NS", "display": "HUL", "exchange": "NSE"},
        {"symbol": "ITC.NS", "display": "ITC", "exchange": "NSE"},
        {"symbol": "SBIN.NS", "display": "SBI", "exchange": "NSE"},
        {"symbol": "BHARTIARTL.NS", "display": "Bharti Airtel", "exchange": "NSE"},
        {"symbol": "KOTAKBANK.NS", "display": "Kotak Bank", "exchange": "NSE"},
        {"symbol": "LT.NS", "display": "L&T", "exchange": "NSE"},
        {"symbol": "AXISBANK.NS", "display": "Axis Bank", "exchange": "NSE"},
        {"symbol": "ASIANPAINT.NS", "display": "Asian Paints", "exchange": "NSE"},
        {"symbol": "BAJFINANCE.NS", "display": "Bajaj Finance", "exchange": "NSE"},
        {"symbol": "MARUTI.NS", "display": "Maruti Suzuki", "exchange": "NSE"},
        {"symbol": "HCLTECH.NS", "display": "HCL Tech", "exchange": "NSE"},
        {"symbol": "WIPRO.NS", "display": "Wipro", "exchange": "NSE"},
        {"symbol": "ULTRACEMCO.NS", "display": "UltraTech Cement", "exchange": "NSE"},
        {"symbol": "TITAN.NS", "display": "Titan", "exchange": "NSE"},
        {"symbol": "SUNPHARMA.NS", "display": "Sun Pharma", "exchange": "NSE"},
        {"symbol": "ONGC.NS", "display": "ONGC", "exchange": "NSE"},
        {"symbol": "NTPC.NS", "display": "NTPC", "exchange": "NSE"},
        {"symbol": "POWERGRID.NS", "display": "Power Grid", "exchange": "NSE"},
        {"symbol": "ADANIPORTS.NS", "display": "Adani Ports", "exchange": "NSE"},
        {"symbol": "TATAMOTORS.NS", "display": "Tata Motors", "exchange": "NSE"},
    ],
    "fo": [
        {"symbol": "^NSEI", "display": "Nifty 50", "nse_symbol": "NIFTY", "exchange": "NSE"},
        {"symbol": "^NSEBANK", "display": "Bank Nifty", "nse_symbol": "BANKNIFTY", "exchange": "NSE"},
        {"symbol": "NIFTY_FIN_SERVICE.NS", "display": "Fin Nifty", "nse_symbol": "FINNIFTY", "exchange": "NSE"},
    ],
    "commodity": [
        {"symbol": "GC=F", "display": "Gold", "exchange": "MCX"},
        {"symbol": "SI=F", "display": "Silver", "exchange": "MCX"},
        {"symbol": "CL=F", "display": "Crude Oil", "exchange": "MCX"},
        {"symbol": "NG=F", "display": "Natural Gas", "exchange": "MCX"},
    ],
    "currency": [
        {"symbol": "USDINR=X", "display": "USD/INR", "exchange": "NSE"},
        {"symbol": "EURINR=X", "display": "EUR/INR", "exchange": "NSE"},
        {"symbol": "GBPINR=X", "display": "GBP/INR", "exchange": "NSE"},
    ],
}

MARKET_OVERVIEW_SYMBOLS = {
    "NIFTY50": "^NSEI",
    "BANKNIFTY": "^NSEBANK",
    "SENSEX": "^BSESN",
    "GOLD": "GC=F",
    "CRUDE": "CL=F",
    "USDINR": "USDINR=X",
}


def get_all_instruments() -> list[dict]:
    result = []
    for segment, instruments in INSTRUMENTS.items():
        for inst in instruments:
            result.append({**inst, "segment": segment})
    return result
