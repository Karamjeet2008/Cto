import asyncio
import pandas as pd
import logging
from .base_provider import BaseDataProvider

logger = logging.getLogger(__name__)


class YahooFinanceProvider(BaseDataProvider):
    """Yahoo Finance data provider using yfinance library."""

    async def get_ohlcv(self, symbol: str, period: str = "6mo", interval: str = "1d") -> pd.DataFrame | None:
        try:
            import yfinance as yf
            loop = asyncio.get_event_loop()
            ticker = yf.Ticker(symbol)
            df = await loop.run_in_executor(
                None,
                lambda: ticker.history(period=period, interval=interval, auto_adjust=True)
            )
            if df is None or df.empty:
                logger.warning(f"No OHLCV data for {symbol}")
                return None
            df = df.dropna(subset=["Close"])
            return df
        except Exception as e:
            logger.error(f"Yahoo OHLCV error for {symbol}: {e}")
            return None

    async def get_current_price(self, symbol: str) -> float | None:
        try:
            import yfinance as yf
            loop = asyncio.get_event_loop()
            ticker = yf.Ticker(symbol)
            info = await loop.run_in_executor(None, lambda: ticker.fast_info)
            price = getattr(info, "last_price", None) or getattr(info, "regularMarketPrice", None)
            if price:
                return float(price)
            df = await self.get_ohlcv(symbol, period="1d", interval="1m")
            if df is not None and not df.empty:
                return float(df["Close"].iloc[-1])
            return None
        except Exception as e:
            logger.error(f"Yahoo price error for {symbol}: {e}")
            return None

    async def get_options_chain(self, symbol: str, expiry: str | None = None) -> dict:
        try:
            import yfinance as yf
            loop = asyncio.get_event_loop()
            ticker = yf.Ticker(symbol)
            expirations = await loop.run_in_executor(None, lambda: ticker.options)
            if not expirations:
                return {}
            target_expiry = expiry or expirations[0]
            chain = await loop.run_in_executor(None, lambda: ticker.option_chain(target_expiry))
            return {
                "calls": chain.calls.to_dict("records"),
                "puts": chain.puts.to_dict("records"),
                "expiry": target_expiry,
            }
        except Exception as e:
            logger.error(f"Yahoo options error for {symbol}: {e}")
            return {}

    async def get_oi_data(self, symbol: str) -> dict:
        return {}
