from abc import ABC, abstractmethod
import pandas as pd


class BaseDataProvider(ABC):
    """
    Abstract base class for market data providers.
    Implement this interface to plug in any data source (Yahoo Finance, Kotak Neo, etc.)
    """

    @abstractmethod
    async def get_ohlcv(self, symbol: str, period: str, interval: str) -> pd.DataFrame | None:
        """Fetch OHLCV candlestick data."""
        ...

    @abstractmethod
    async def get_current_price(self, symbol: str) -> float | None:
        """Get latest price for a symbol."""
        ...

    @abstractmethod
    async def get_options_chain(self, symbol: str, expiry: str | None = None) -> dict:
        """Fetch options chain data."""
        ...

    @abstractmethod
    async def get_oi_data(self, symbol: str) -> dict:
        """Fetch open interest data for PCR calculation."""
        ...
