import asyncio
import json
import logging
import pandas as pd
from .yahoo_provider import YahooFinanceProvider
from .nse_provider import NSEProvider
from .base_provider import BaseDataProvider

logger = logging.getLogger(__name__)

OHLCV_CACHE_TTL = 300
PRICE_CACHE_TTL = 60
OI_CACHE_TTL = 600


def create_provider() -> BaseDataProvider:
    """Factory: auto-selects provider based on env config."""
    from app.config import settings
    if all([settings.KOTAK_NEO_API_KEY, settings.KOTAK_NEO_SECRET, settings.KOTAK_NEO_ACCESS_TOKEN]):
        from .kotak_provider import KotakNeoProvider
        logger.info("Using Kotak Neo data provider")
        return KotakNeoProvider(
            settings.KOTAK_NEO_API_KEY,
            settings.KOTAK_NEO_SECRET,
            settings.KOTAK_NEO_ACCESS_TOKEN,
        )
    logger.info("Using Yahoo Finance data provider")
    return YahooFinanceProvider()


class DataAggregator:
    """Aggregates data from multiple providers with caching."""

    def __init__(self, cache=None):
        self.primary = create_provider()
        self.nse = NSEProvider()
        self.cache = cache
        self._memory_cache: dict = {}

    async def _cache_get(self, key: str):
        if self.cache:
            try:
                val = await self.cache.get(key)
                if val:
                    return json.loads(val)
            except Exception:
                pass
        return self._memory_cache.get(key)

    async def _cache_set(self, key: str, value, ttl: int):
        if self.cache:
            try:
                await self.cache.set(key, json.dumps(value, default=str), ex=ttl)
                return
            except Exception:
                pass
        self._memory_cache[key] = value

    async def get_ohlcv(self, symbol: str, period: str = "6mo", interval: str = "1d") -> pd.DataFrame | None:
        cache_key = f"ohlcv:{symbol}:{period}:{interval}"
        cached = await self._cache_get(cache_key)
        if cached:
            try:
                df = pd.DataFrame(cached)
                if "Date" in df.columns:
                    df["Date"] = pd.to_datetime(df["Date"])
                    df = df.set_index("Date")
                elif "Datetime" in df.columns:
                    df["Datetime"] = pd.to_datetime(df["Datetime"])
                    df = df.set_index("Datetime")
                return df
            except Exception:
                pass

        df = await self.primary.get_ohlcv(symbol, period, interval)
        if df is not None and not df.empty:
            try:
                serializable = df.reset_index()
                await self._cache_set(cache_key, serializable.to_dict("records"), OHLCV_CACHE_TTL)
            except Exception:
                pass
        return df

    async def get_current_price(self, symbol: str) -> float | None:
        cache_key = f"price:{symbol}"
        cached = await self._cache_get(cache_key)
        if cached:
            return float(cached)

        price = await self.primary.get_current_price(symbol)
        if price:
            await self._cache_set(cache_key, price, PRICE_CACHE_TTL)
        return price

    async def get_oi_data(self, symbol: str) -> dict:
        cache_key = f"oi:{symbol}"
        cached = await self._cache_get(cache_key)
        if cached:
            return cached

        oi_data = await self.nse.get_oi_data(symbol)
        if oi_data:
            await self._cache_set(cache_key, oi_data, OI_CACHE_TTL)
        return oi_data

    async def get_market_overview(self) -> dict:
        from app.engine.instruments import MARKET_OVERVIEW_SYMBOLS
        tasks = {key: self.get_current_price(sym) for key, sym in MARKET_OVERVIEW_SYMBOLS.items()}
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)
        overview = {}
        for key, result in zip(tasks.keys(), results):
            if isinstance(result, Exception) or result is None:
                overview[key] = None
            else:
                overview[key] = result
        return overview
