import httpx
import logging
import asyncio
from .base_provider import BaseDataProvider
import pandas as pd

logger = logging.getLogger(__name__)

NSE_BASE = "https://www.nseindia.com/api"


class NSEProvider(BaseDataProvider):
    """NSE public API provider for options chain and OI data."""

    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://www.nseindia.com",
        "Connection": "keep-alive",
    }

    async def _get_with_session(self, url: str) -> dict | None:
        try:
            async with httpx.AsyncClient(
                headers=self.HEADERS,
                timeout=15,
                follow_redirects=True,
            ) as client:
                await client.get("https://www.nseindia.com", timeout=10)
                await asyncio.sleep(1)
                r = await client.get(url)
                r.raise_for_status()
                return r.json()
        except Exception as e:
            logger.warning(f"NSE API error for {url}: {e}")
            return None

    async def get_options_chain(self, symbol: str, expiry: str | None = None) -> dict:
        url = f"{NSE_BASE}/option-chain-indices?symbol={symbol}"
        if symbol not in ["NIFTY", "BANKNIFTY", "FINNIFTY"]:
            url = f"{NSE_BASE}/option-chain-equities?symbol={symbol}"
        data = await self._get_with_session(url)
        return data or {}

    async def get_oi_data(self, symbol: str) -> dict:
        chain_data = await self.get_options_chain(symbol)
        if not chain_data:
            return {}
        return self._parse_oi(chain_data)

    def _parse_oi(self, chain_data: dict) -> dict:
        try:
            records = chain_data.get("records", {}).get("data", [])
            total_call_oi = 0
            total_put_oi = 0
            atm_strike = None
            underlying = chain_data.get("records", {}).get("underlyingValue", 0)

            for record in records:
                ce = record.get("CE", {})
                pe = record.get("PE", {})
                total_call_oi += ce.get("openInterest", 0)
                total_put_oi += pe.get("openInterest", 0)

            pcr = total_put_oi / total_call_oi if total_call_oi > 0 else 1.0

            max_call_oi = 0
            max_put_oi = 0
            call_resistance = None
            put_support = None

            for record in records:
                ce = record.get("CE", {})
                pe = record.get("PE", {})
                strike = record.get("strikePrice", 0)
                ce_oi = ce.get("openInterest", 0)
                pe_oi = pe.get("openInterest", 0)
                if ce_oi > max_call_oi:
                    max_call_oi = ce_oi
                    call_resistance = strike
                if pe_oi > max_put_oi:
                    max_put_oi = pe_oi
                    put_support = strike

            return {
                "total_call_oi": total_call_oi,
                "total_put_oi": total_put_oi,
                "pcr": pcr,
                "call_resistance": call_resistance,
                "put_support": put_support,
                "underlying": underlying,
            }
        except Exception as e:
            logger.error(f"OI parse error: {e}")
            return {}

    async def get_ohlcv(self, symbol: str, period: str, interval: str) -> pd.DataFrame | None:
        return None

    async def get_current_price(self, symbol: str) -> float | None:
        return None
