from .base_provider import BaseDataProvider
import pandas as pd


class KotakNeoProvider(BaseDataProvider):
    """
    Drop-in replacement for YahooFinanceProvider.
    Implements the same BaseDataProvider interface using Kotak Neo API.
    Configure via KOTAK_NEO_API_KEY, KOTAK_NEO_SECRET, KOTAK_NEO_ACCESS_TOKEN env vars.
    """

    def __init__(self, api_key: str, secret: str, access_token: str):
        self.api_key = api_key
        self.secret = secret
        self.access_token = access_token

    async def get_ohlcv(self, symbol: str, period: str, interval: str) -> pd.DataFrame | None:
        raise NotImplementedError("Configure Kotak Neo credentials to activate real-time data")

    async def get_current_price(self, symbol: str) -> float | None:
        raise NotImplementedError("Configure Kotak Neo credentials to activate real-time data")

    async def get_options_chain(self, symbol: str, expiry: str | None = None) -> dict:
        raise NotImplementedError("Configure Kotak Neo credentials to activate real-time data")

    async def get_oi_data(self, symbol: str) -> dict:
        raise NotImplementedError("Configure Kotak Neo credentials to activate real-time data")
