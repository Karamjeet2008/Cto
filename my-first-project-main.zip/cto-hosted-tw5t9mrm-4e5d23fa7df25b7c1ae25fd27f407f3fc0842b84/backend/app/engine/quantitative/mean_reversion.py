import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class MeanReversionModel:
    """
    Z-score mean reversion model.
    Extreme deviations from rolling mean suggest reversion opportunity.
    Z > 2: overbought (bearish), Z < -2: oversold (bullish)
    """

    def score(self, df: pd.DataFrame, window: int = 20) -> dict:
        close = df["Close"].dropna()
        if len(close) < window + 1:
            return {"score": 0.0, "z_score": 0.0}

        rolling_mean = close.rolling(window).mean()
        rolling_std = close.rolling(window).std()

        current = float(close.iloc[-1])
        mean_val = float(rolling_mean.dropna().iloc[-1])
        std_val = float(rolling_std.dropna().iloc[-1])

        if std_val < 1e-9:
            return {"score": 0.0, "z_score": 0.0}

        z_score = (current - mean_val) / std_val
        reversion_signal = float(np.clip(-z_score / 2.5, -1.0, 1.0))

        return {
            "score": reversion_signal,
            "z_score": round(z_score, 2),
            "is_overbought": z_score > 2.0,
            "is_oversold": z_score < -2.0,
            "mean": round(mean_val, 2),
            "std": round(std_val, 2),
        }
