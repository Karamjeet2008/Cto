import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class MomentumModel:
    """
    Multi-timeframe momentum using rates of change across 5d, 10d, 20d, 60d.
    Returns score: -1 (strong bearish) to +1 (strong bullish).
    """

    WINDOWS = [5, 10, 20, 60]
    WEIGHTS = [0.4, 0.3, 0.2, 0.1]

    def score(self, df: pd.DataFrame) -> dict:
        close = df["Close"].dropna()
        if len(close) < 10:
            return {"score": 0.0}

        scores = []
        roc_values = {}

        for i, window in enumerate(self.WINDOWS):
            if len(close) < window + 1:
                continue
            roc = (float(close.iloc[-1]) - float(close.iloc[-1 - window])) / float(close.iloc[-1 - window])
            normalized = float(np.clip(roc * 10, -1, 1))
            scores.append((normalized, self.WEIGHTS[i]))
            roc_values[f"roc_{window}d"] = round(roc * 100, 2)

        if not scores:
            return {"score": 0.0}

        total_weight = sum(w for _, w in scores)
        weighted = sum(s * w for s, w in scores) / total_weight if total_weight > 0 else 0.0

        return {
            "score": float(np.clip(weighted, -1.0, 1.0)),
            **roc_values,
        }
