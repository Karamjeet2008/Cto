import numpy as np
import pandas as pd
from .momentum_model import MomentumModel
from .mean_reversion import MeanReversionModel


class QuantScorer:

    def __init__(self):
        self.momentum = MomentumModel()
        self.mean_rev = MeanReversionModel()

    def score(self, df: pd.DataFrame) -> dict:
        mom = self.momentum.score(df)
        mean_rev = self.mean_rev.score(df)

        combined = mom["score"] * 0.6 + mean_rev["score"] * 0.4
        combined = float(np.clip(combined, -1.0, 1.0))

        return {
            "score": combined,
            "momentum": mom,
            "mean_reversion": mean_rev,
        }
