import numpy as np
import logging

logger = logging.getLogger(__name__)


class SignalFusion:
    """
    Multi-layer weighted ensemble combining TA, sentiment, quant, and options signals.
    Dynamically adjusts weights per segment and data availability.
    """

    BASE_WEIGHTS = {
        "equity": {"ta": 0.40, "sentiment": 0.20, "quant": 0.25, "options": 0.15},
        "fo": {"ta": 0.30, "sentiment": 0.15, "quant": 0.20, "options": 0.35},
        "commodity": {"ta": 0.45, "sentiment": 0.25, "quant": 0.25, "options": 0.05},
        "currency": {"ta": 0.40, "sentiment": 0.30, "quant": 0.25, "options": 0.05},
    }

    def fuse(
        self,
        ta_result: dict,
        sentiment_result: dict,
        quant_result: dict,
        options_result: dict,
        segment: str,
        min_confidence: float = 55.0,
    ) -> dict:
        weights = dict(self.BASE_WEIGHTS.get(segment, self.BASE_WEIGHTS["equity"]))

        options_score = options_result.get("score")
        if options_score is None or options_score == 0:
            redistribution = weights["options"]
            weights["ta"] += redistribution * 0.4
            weights["quant"] += redistribution * 0.35
            weights["sentiment"] += redistribution * 0.25
            weights["options"] = 0.0

        sentiment_conf = sentiment_result.get("confidence", 0.5)
        if sentiment_conf < 0.2:
            redistribution = weights["sentiment"] * 0.5
            weights["ta"] += redistribution * 0.6
            weights["quant"] += redistribution * 0.4
            weights["sentiment"] -= redistribution

        total_weight = sum(weights.values())
        if total_weight > 0:
            weights = {k: v / total_weight for k, v in weights.items()}

        ta_score = float(ta_result.get("score", 0))
        sentiment_score = float(sentiment_result.get("score", 0))
        quant_score = float(quant_result.get("score", 0))
        opt_score = float(options_score or 0)

        raw_score = (
            weights["ta"] * ta_score
            + weights["sentiment"] * sentiment_score
            + weights["quant"] * quant_score
            + weights["options"] * opt_score
        )
        raw_score = float(np.clip(raw_score, -1.0, 1.0))

        layer_scores_list = [s for s in [ta_score, sentiment_score, quant_score] if s != 0]
        if options_score and options_score != 0:
            layer_scores_list.append(float(options_score))

        if layer_scores_list:
            all_positive = all(s > 0 for s in layer_scores_list)
            all_negative = all(s < 0 for s in layer_scores_list)
            agreement_bonus = 1.18 if (all_positive or all_negative) else 0.88
        else:
            agreement_bonus = 1.0

        confidence = min(abs(raw_score) * 100 * agreement_bonus, 100.0)

        signal_type = "BUY" if raw_score >= 0 else "SELL"

        return {
            "signal_type": signal_type,
            "raw_score": round(raw_score, 4),
            "confidence_score": round(confidence, 1),
            "is_publishable": confidence >= min_confidence,
            "weights_used": weights,
            "layer_scores": {
                "technical": round(ta_score * 100, 1),
                "sentiment": round(sentiment_score * 100, 1),
                "quantitative": round(quant_score * 100, 1),
                "options": round(opt_score * 100, 1),
            },
        }
