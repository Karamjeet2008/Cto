import httpx
import logging
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

GOOGLE_NEWS_RSS = "https://news.google.com/rss/search?q={query}+NSE+stock&hl=en-IN&gl=IN&ceid=IN:en"
ET_RSS = "https://economictimes.indiatimes.com/markets/rss.cms"


class NewsFetcher:
    """Fetches financial news from free RSS sources."""

    async def fetch_for_instrument(self, display_name: str, limit: int = 20) -> list[dict]:
        results = []
        query = display_name.replace(" ", "+")
        url = GOOGLE_NEWS_RSS.format(query=query)

        try:
            async with httpx.AsyncClient(
                timeout=10,
                headers={"User-Agent": "Mozilla/5.0 (compatible; NewsBot/1.0)"},
                follow_redirects=True,
            ) as client:
                r = await client.get(url)
                if r.status_code == 200:
                    soup = BeautifulSoup(r.text, "lxml-xml")
                    items = soup.find_all("item")
                    for item in items[:limit]:
                        title = item.find("title")
                        desc = item.find("description")
                        pub_date = item.find("pubDate")
                        results.append({
                            "title": title.get_text() if title else "",
                            "description": desc.get_text() if desc else "",
                            "published_at": pub_date.get_text() if pub_date else "",
                            "source": "google_news",
                        })
        except Exception as e:
            logger.debug(f"News fetch error for {display_name}: {e}")

        return results

    async def fetch_market_news(self, limit: int = 20) -> list[dict]:
        results = []
        try:
            async with httpx.AsyncClient(timeout=10, follow_redirects=True) as client:
                r = await client.get(ET_RSS)
                if r.status_code == 200:
                    soup = BeautifulSoup(r.text, "lxml-xml")
                    items = soup.find_all("item")
                    for item in items[:limit]:
                        title = item.find("title")
                        desc = item.find("description")
                        results.append({
                            "title": title.get_text() if title else "",
                            "description": desc.get_text() if desc else "",
                            "source": "economic_times",
                        })
        except Exception as e:
            logger.debug(f"ET news fetch error: {e}")

        return results
