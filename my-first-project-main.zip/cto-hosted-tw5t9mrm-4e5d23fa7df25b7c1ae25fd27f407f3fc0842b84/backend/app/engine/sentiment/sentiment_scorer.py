import logging

logger = logging.getLogger(__name__)

BULLISH_KEYWORDS = [
    "surge", "rally", "breakout", "gains", "bullish", "upgrade", "beat", "outperform",
    "record high", "strong results", "buy", "positive", "growth", "profit", "dividend",
    "acquisition", "deal", "partnership", "expansion", "robust", "beat estimates",
    "strong demand", "order win", "contract", "new high", "recovery", "jumps", "soars",
    "exceeds", "milestone", "launches", "approval", "rating upgrade", "overweight",
]

BEARISH_KEYWORDS = [
    "crash", "fall", "drop", "bearish", "downgrade", "miss", "loss", "sell", "underperform",
    "negative", "weak", "decline", "penalty", "fraud", "investigation", "lawsuit",
    "revenue miss", "disappoints", "cut", "probe", "default", "slump", "plunges",
    "headwinds", "warning", "recall", "violation", "fine", "concern", "uncertainty",
    "miss estimates", "below expectations", "pressure", "struggles", "sinks",
]


class SentimentScorer:

    def score(self, articles: list[dict]) -> dict:
        if not articles:
            return {"score": 0.0, "confidence": 0.1, "article_count": 0}

        scores = []
        bullish_total = 0
        bearish_total = 0

        for art in articles:
            text = (art.get("title", "") + " " + art.get("description", "")).lower()
            bull_hits = sum(1 for k in BULLISH_KEYWORDS if k in text)
            bear_hits = sum(1 for k in BEARISH_KEYWORDS if k in text)
            total = bull_hits + bear_hits
            if total > 0:
                score = (bull_hits - bear_hits) / total
                scores.append(score)
                bullish_total += bull_hits
                bearish_total += bear_hits

        if not scores:
            return {"score": 0.0, "confidence": 0.1, "article_count": len(articles)}

        avg_score = sum(scores) / len(scores)
        confidence = min(len(scores) / 8.0, 1.0)

        return {
            "score": float(avg_score),
            "confidence": float(confidence),
            "article_count": len(articles),
            "scored_articles": len(scores),
            "bullish_signals": bullish_total,
            "bearish_signals": bearish_total,
        }
