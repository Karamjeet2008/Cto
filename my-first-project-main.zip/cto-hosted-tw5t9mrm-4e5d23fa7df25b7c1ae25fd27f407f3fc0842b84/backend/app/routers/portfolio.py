from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.routers.auth import get_current_user
from app.services.portfolio_service import get_portfolio_summary, get_portfolio_chart
from app.schemas.portfolio import PortfolioSummary, PortfolioChartResponse, PortfolioSnapshotResponse

router = APIRouter(prefix="/portfolio", tags=["portfolio"])


@router.get("", response_model=PortfolioSummary)
async def portfolio_summary(
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    summary = await get_portfolio_summary(user.id, db)
    return PortfolioSummary(**summary)


@router.get("/chart", response_model=PortfolioChartResponse)
async def portfolio_chart(
    period: str = Query("30d"),
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    limit_map = {"7d": 7 * 24, "30d": 30 * 24, "90d": 90 * 24, "all": 10000}
    limit = limit_map.get(period, 720)
    snapshots = await get_portfolio_chart(user.id, db, limit=limit)
    return PortfolioChartResponse(
        snapshots=[PortfolioSnapshotResponse.model_validate(s) for s in snapshots],
        period=period,
    )
