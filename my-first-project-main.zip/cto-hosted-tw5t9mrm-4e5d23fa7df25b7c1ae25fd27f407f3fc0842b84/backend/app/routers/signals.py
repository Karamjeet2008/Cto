from fastapi import APIRouter, Depends, Query
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.services.signal_service import (
    get_active_signals, get_signal_by_id, get_signals_history,
    get_signal_accuracy_stats,
)
from app.schemas.signal import SignalResponse, SignalListResponse, SignalAccuracyStats

router = APIRouter(prefix="/signals", tags=["signals"])


@router.get("", response_model=SignalListResponse)
async def list_signals(
    segment: Optional[str] = Query(None),
    signal_type: Optional[str] = Query(None),
    min_confidence: float = Query(0.0),
    limit: int = Query(50, le=100),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
):
    signals, total = await get_active_signals(
        db,
        segment=segment,
        signal_type=signal_type,
        min_confidence=min_confidence,
        limit=limit,
        offset=offset,
    )
    active_count = len(signals)
    return SignalListResponse(
        signals=[SignalResponse.model_validate(s) for s in signals],
        total=total,
        active_count=active_count,
    )


@router.get("/history", response_model=SignalListResponse)
async def signal_history(
    status: Optional[str] = Query(None),
    segment: Optional[str] = Query(None),
    limit: int = Query(50, le=100),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
):
    signals, total = await get_signals_history(db, status=status, segment=segment, limit=limit, offset=offset)
    return SignalListResponse(
        signals=[SignalResponse.model_validate(s) for s in signals],
        total=total,
        active_count=0,
    )


@router.get("/accuracy", response_model=SignalAccuracyStats)
async def signal_accuracy(db: AsyncSession = Depends(get_db)):
    stats = await get_signal_accuracy_stats(db)
    return SignalAccuracyStats(**stats)


@router.get("/{signal_id}", response_model=SignalResponse)
async def get_signal(signal_id: str, db: AsyncSession = Depends(get_db)):
    from fastapi import HTTPException
    signal = await get_signal_by_id(signal_id, db)
    if not signal:
        raise HTTPException(status_code=404, detail="Signal not found")
    return SignalResponse.model_validate(signal)
