from fastapi import APIRouter, Depends, Query
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.routers.auth import get_current_user
from app.services.trade_service import take_trade, get_user_trades
from app.schemas.trade import TakeTradeRequest, TradeResponse, TradeListResponse

router = APIRouter(prefix="/trades", tags=["trades"])


@router.post("/take", response_model=TradeResponse)
async def execute_trade(
    body: TakeTradeRequest,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.engine.data.data_aggregator import DataAggregator
    from app.redis_client import get_redis

    redis = await get_redis()
    aggregator = DataAggregator(cache=redis)
    trade = await take_trade(
        user_id=user.id,
        signal_id=body.signal_id,
        quantity=body.quantity,
        db=db,
        data_aggregator=aggregator,
    )
    return TradeResponse.model_validate(trade)


@router.get("", response_model=TradeListResponse)
async def list_trades(
    status: Optional[str] = Query(None),
    limit: int = Query(50, le=100),
    offset: int = Query(0),
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    trades, total = await get_user_trades(user.id, db, status=status, limit=limit, offset=offset)

    open_count = sum(1 for t in trades if t.status in ["open", "target1_hit"])
    total_pnl = sum(float(t.pnl or 0) for t in trades)

    trade_list = []
    for t in trades:
        trade_dict = {
            "id": t.id,
            "user_id": t.user_id,
            "signal_id": t.signal_id,
            "quantity": float(t.quantity),
            "entry_price": float(t.entry_price),
            "exit_price": float(t.exit_price) if t.exit_price else None,
            "current_price": float(t.current_price),
            "pnl": float(t.pnl or 0),
            "pnl_pct": float(t.pnl_pct or 0),
            "status": str(t.status),
            "exit_reason": t.exit_reason,
            "opened_at": t.opened_at,
            "closed_at": t.closed_at,
        }
        trade_list.append(trade_dict)

    return TradeListResponse(
        trades=[TradeResponse(**t) for t in trade_list],
        total=total,
        open_count=open_count,
        total_pnl=round(total_pnl, 2),
    )


@router.get("/{trade_id}", response_model=TradeResponse)
async def get_trade(
    trade_id: str,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from fastapi import HTTPException
    from sqlalchemy import select
    from app.models.trade import PaperTrade

    result = await db.execute(
        select(PaperTrade).where(PaperTrade.id == trade_id, PaperTrade.user_id == user.id)
    )
    trade = result.scalar_one_or_none()
    if not trade:
        raise HTTPException(status_code=404, detail="Trade not found")
    return TradeResponse.model_validate(trade)
