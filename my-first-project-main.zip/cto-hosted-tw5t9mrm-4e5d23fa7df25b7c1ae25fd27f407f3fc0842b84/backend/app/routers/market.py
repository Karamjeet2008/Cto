from fastapi import APIRouter, Depends
from app.redis_client import get_redis
from app.engine.data.data_aggregator import DataAggregator
from app.engine.instruments import MARKET_OVERVIEW_SYMBOLS

router = APIRouter(prefix="/market", tags=["market"])


@router.get("/overview")
async def market_overview(redis=Depends(get_redis)):
    aggregator = DataAggregator(cache=redis)
    prices = await aggregator.get_market_overview()

    result = {}
    for key, symbol in MARKET_OVERVIEW_SYMBOLS.items():
        price = prices.get(key)
        result[key] = {
            "symbol": symbol,
            "price": price,
            "change": None,
            "change_pct": None,
        }
    return result


@router.get("/price/{symbol}")
async def get_price(symbol: str, redis=Depends(get_redis)):
    aggregator = DataAggregator(cache=redis)
    price = await aggregator.get_current_price(symbol)
    return {"symbol": symbol, "price": price}
