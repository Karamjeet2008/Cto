import asyncio
import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

logger = logging.getLogger(__name__)

_scheduler = None


def get_scheduler() -> AsyncIOScheduler:
    global _scheduler
    if _scheduler is None:
        _scheduler = AsyncIOScheduler(timezone="Asia/Kolkata")
    return _scheduler


async def run_signal_engine():
    logger.info("Running signal engine...")
    try:
        from app.database import AsyncSessionLocal
        from app.engine.data.data_aggregator import DataAggregator
        from app.engine.pipeline import SignalPipeline
        from app.services.signal_service import create_signal
        from app.services.notification_service import broadcast_new_signal
        from app.redis_client import get_redis

        redis = await get_redis()
        aggregator = DataAggregator(cache=redis)
        pipeline = SignalPipeline(aggregator)

        signals = await pipeline.run_all(max_concurrent=5)

        async with AsyncSessionLocal() as db:
            for signal_data in signals:
                try:
                    signal = await create_signal(signal_data, db)
                    await broadcast_new_signal({
                        "id": signal.id,
                        "instrument": signal.instrument,
                        "display_name": signal.display_name,
                        "segment": str(signal.segment),
                        "signal_type": str(signal.signal_type),
                        "entry_price": float(signal.entry_price),
                        "stop_loss": float(signal.stop_loss),
                        "target1": float(signal.target1),
                        "target2": float(signal.target2),
                        "confidence_score": float(signal.confidence_score),
                        "risk_reward_ratio": float(signal.risk_reward_ratio),
                        "ai_reasoning": signal.ai_reasoning,
                    })
                except Exception as e:
                    logger.error(f"Failed to persist signal: {e}")

        logger.info(f"Signal engine complete: {len(signals)} signals published")
    except Exception as e:
        logger.error(f"Signal engine error: {e}", exc_info=True)


async def update_pnl():
    try:
        from app.database import AsyncSessionLocal
        from app.engine.data.data_aggregator import DataAggregator
        from app.services.trade_service import update_open_trades_pnl
        from app.services.notification_service import broadcast_pnl_updates
        from app.redis_client import get_redis

        redis = await get_redis()
        aggregator = DataAggregator(cache=redis)

        async with AsyncSessionLocal() as db:
            updates = await update_open_trades_pnl(db, aggregator)
            if updates:
                await broadcast_pnl_updates(updates)
    except Exception as e:
        logger.error(f"P&L update error: {e}")


async def check_signal_status():
    try:
        from app.database import AsyncSessionLocal
        from app.services.signal_service import expire_old_signals

        async with AsyncSessionLocal() as db:
            expired = await expire_old_signals(db)
            if expired > 0:
                logger.info(f"Expired {expired} signals")
    except Exception as e:
        logger.error(f"Signal status check error: {e}")


async def portfolio_snapshot():
    try:
        from app.database import AsyncSessionLocal
        from app.services.portfolio_service import take_all_snapshots

        async with AsyncSessionLocal() as db:
            await take_all_snapshots(db)
    except Exception as e:
        logger.error(f"Portfolio snapshot error: {e}")


async def broadcast_market_data():
    try:
        from app.engine.data.data_aggregator import DataAggregator
        from app.services.notification_service import broadcast_market_tick
        from app.redis_client import get_redis

        redis = await get_redis()
        aggregator = DataAggregator(cache=redis)
        overview = await aggregator.get_market_overview()
        if any(v is not None for v in overview.values()):
            await broadcast_market_tick(overview)
    except Exception as e:
        logger.debug(f"Market broadcast error: {e}")


def setup_scheduler(run_on_start: bool = False) -> AsyncIOScheduler:
    scheduler = get_scheduler()

    scheduler.add_job(
        run_signal_engine,
        CronTrigger(
            day_of_week="mon-fri",
            hour="9-15",
            minute="*/15",
            timezone="Asia/Kolkata",
        ),
        id="signal_engine",
        replace_existing=True,
        misfire_grace_time=300,
    )

    scheduler.add_job(
        update_pnl,
        IntervalTrigger(seconds=60),
        id="pnl_updater",
        replace_existing=True,
    )

    scheduler.add_job(
        check_signal_status,
        IntervalTrigger(minutes=5),
        id="signal_monitor",
        replace_existing=True,
    )

    scheduler.add_job(
        portfolio_snapshot,
        IntervalTrigger(hours=1),
        id="portfolio_snapshot",
        replace_existing=True,
    )

    scheduler.add_job(
        broadcast_market_data,
        IntervalTrigger(seconds=30),
        id="market_broadcast",
        replace_existing=True,
    )

    if run_on_start:
        scheduler.add_job(
            run_signal_engine,
            "date",
            id="signal_engine_startup",
        )

    return scheduler
