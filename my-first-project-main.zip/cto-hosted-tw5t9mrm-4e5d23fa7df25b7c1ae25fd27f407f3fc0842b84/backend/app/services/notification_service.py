import logging
from app.websocket_manager import manager

logger = logging.getLogger(__name__)


async def broadcast_new_signal(signal_data: dict):
    await manager.broadcast({
        "type": "new_signal",
        "data": signal_data,
    })


async def broadcast_signal_update(signal_data: dict):
    await manager.broadcast({
        "type": "signal_update",
        "data": signal_data,
    })


async def broadcast_market_tick(market_data: dict):
    await manager.broadcast({
        "type": "market_tick",
        "data": market_data,
    })


async def send_pnl_update(user_id: str, trade_data: dict):
    await manager.send_to_user(user_id, {
        "type": "pnl_update",
        "data": trade_data,
    })


async def broadcast_pnl_updates(trade_updates: list[dict]):
    for update in trade_updates:
        user_id = update.get("user_id")
        if user_id:
            await send_pnl_update(user_id, update)
