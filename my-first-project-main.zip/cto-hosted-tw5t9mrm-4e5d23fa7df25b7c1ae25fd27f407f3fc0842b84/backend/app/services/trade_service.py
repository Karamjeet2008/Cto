from datetime import datetime
from typing import Optional
import uuid
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from fastapi import HTTPException
from app.models.trade import PaperTrade, TradeStatusEnum
from app.models.signal import Signal, SignalStatusEnum
from app.models.user import User

logger = logging.getLogger(__name__)


async def take_trade(
    user_id: str,
    signal_id: str,
    quantity: float,
    db: AsyncSession,
    data_aggregator=None,
) -> PaperTrade:
    signal_result = await db.execute(select(Signal).where(Signal.id == signal_id))
    signal = signal_result.scalar_one_or_none()
    if not signal:
        raise HTTPException(status_code=404, detail="Signal not found")
    if signal.status != SignalStatusEnum.active:
        raise HTTPException(status_code=400, detail="Signal is no longer active")

    user_result = await db.execute(select(User).where(User.id == user_id))
    user = user_result.scalar_one_or_none()
    if not user or float(user.virtual_capital) == 0:
        raise HTTPException(status_code=400, detail="Please set your virtual capital first")

    entry_price = float(signal.entry_price)
    if data_aggregator:
        try:
            live_price = await data_aggregator.get_current_price(signal.instrument)
            if live_price:
                entry_price = live_price
        except Exception:
            pass

    trade_value = entry_price * quantity
    used_capital = await get_used_capital(user_id, db)
    available = float(user.virtual_capital) - used_capital

    if trade_value > available:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient virtual capital. Available: ₹{available:,.2f}, Required: ₹{trade_value:,.2f}",
        )

    trade = PaperTrade(
        id=str(uuid.uuid4()),
        user_id=user_id,
        signal_id=signal_id,
        quantity=quantity,
        entry_price=entry_price,
        current_price=entry_price,
        pnl=0.0,
        pnl_pct=0.0,
        status=TradeStatusEnum.open,
        opened_at=datetime.utcnow(),
    )
    db.add(trade)
    await db.commit()
    await db.refresh(trade)
    return trade


async def get_used_capital(user_id: str, db: AsyncSession) -> float:
    result = await db.execute(
        select(func.sum(PaperTrade.entry_price * PaperTrade.quantity)).where(
            and_(
                PaperTrade.user_id == user_id,
                PaperTrade.status.in_([TradeStatusEnum.open, TradeStatusEnum.target1_hit]),
            )
        )
    )
    val = result.scalar()
    return float(val) if val else 0.0


async def get_user_trades(
    user_id: str,
    db: AsyncSession,
    status: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[PaperTrade], int]:
    query = select(PaperTrade).where(PaperTrade.user_id == user_id)
    if status:
        query = query.where(PaperTrade.status == status)

    count_result = await db.execute(select(func.count()).select_from(query.subquery()))
    total = count_result.scalar() or 0

    query = query.order_by(PaperTrade.opened_at.desc()).limit(limit).offset(offset)
    result = await db.execute(query)
    return list(result.scalars().all()), total


async def close_trade(
    trade: PaperTrade,
    exit_price: float,
    reason: str,
    db: AsyncSession,
) -> PaperTrade:
    trade.exit_price = exit_price
    trade.current_price = exit_price
    trade.exit_reason = reason
    trade.closed_at = datetime.utcnow()

    signal_result = await db.execute(select(Signal).where(Signal.id == trade.signal_id))
    signal = signal_result.scalar_one_or_none()

    if signal:
        if signal.signal_type == "BUY":
            pnl = (exit_price - float(trade.entry_price)) * float(trade.quantity)
        else:
            pnl = (float(trade.entry_price) - exit_price) * float(trade.quantity)
        trade.pnl = round(pnl, 2)
        trade.pnl_pct = round(pnl / (float(trade.entry_price) * float(trade.quantity)) * 100, 2)

    if reason == "sl_hit":
        trade.status = TradeStatusEnum.sl_hit
    elif reason == "target2_hit":
        trade.status = TradeStatusEnum.target2_hit
    elif reason == "target1_hit":
        trade.status = TradeStatusEnum.target1_hit
    else:
        trade.status = TradeStatusEnum.closed

    await db.commit()
    await db.refresh(trade)
    return trade


async def update_open_trades_pnl(db: AsyncSession, data_aggregator=None) -> list[dict]:
    result = await db.execute(
        select(PaperTrade).where(
            PaperTrade.status.in_([TradeStatusEnum.open, TradeStatusEnum.target1_hit])
        )
    )
    open_trades = result.scalars().all()
    updates = []

    for trade in open_trades:
        signal_result = await db.execute(select(Signal).where(Signal.id == trade.signal_id))
        signal = signal_result.scalar_one_or_none()
        if not signal:
            continue

        current_price = None
        if data_aggregator:
            try:
                current_price = await data_aggregator.get_current_price(signal.instrument)
            except Exception:
                pass

        if not current_price:
            current_price = float(trade.current_price)

        trade.current_price = current_price

        if signal.signal_type == "BUY":
            pnl = (current_price - float(trade.entry_price)) * float(trade.quantity)
            if current_price <= float(signal.stop_loss):
                await close_trade(trade, current_price, "sl_hit", db)
            elif current_price >= float(signal.target2):
                await close_trade(trade, current_price, "target2_hit", db)
                await _update_signal_status(signal, "target2_hit", db)
            elif current_price >= float(signal.target1):
                trade.status = TradeStatusEnum.target1_hit
        else:
            pnl = (float(trade.entry_price) - current_price) * float(trade.quantity)
            if current_price >= float(signal.stop_loss):
                await close_trade(trade, current_price, "sl_hit", db)
            elif current_price <= float(signal.target2):
                await close_trade(trade, current_price, "target2_hit", db)
                await _update_signal_status(signal, "target2_hit", db)
            elif current_price <= float(signal.target1):
                trade.status = TradeStatusEnum.target1_hit

        trade.pnl = round(pnl, 2)
        trade.pnl_pct = round(pnl / (float(trade.entry_price) * float(trade.quantity)) * 100, 2)

        updates.append({
            "trade_id": trade.id,
            "user_id": trade.user_id,
            "current_price": current_price,
            "pnl": trade.pnl,
            "pnl_pct": trade.pnl_pct,
            "status": str(trade.status),
        })

    if open_trades:
        await db.commit()

    return updates


async def _update_signal_status(signal: Signal, status: str, db: AsyncSession):
    signal.status = status
    signal.updated_at = datetime.utcnow()
    await db.commit()
