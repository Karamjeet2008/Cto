from datetime import datetime, timedelta
from typing import Optional
import uuid
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc, and_
from app.models.signal import Signal, SignalOutcome, SignalStatusEnum
from app.schemas.signal import SignalAccuracyStats

logger = logging.getLogger(__name__)


async def create_signal(signal_data: dict, db: AsyncSession) -> Signal:
    signal = Signal(
        id=str(uuid.uuid4()),
        **{k: v for k, v in signal_data.items() if hasattr(Signal, k)},
    )
    db.add(signal)
    await db.commit()
    await db.refresh(signal)
    return signal


async def get_signal_by_id(signal_id: str, db: AsyncSession) -> Optional[Signal]:
    result = await db.execute(select(Signal).where(Signal.id == signal_id))
    return result.scalar_one_or_none()


async def get_active_signals(
    db: AsyncSession,
    segment: Optional[str] = None,
    signal_type: Optional[str] = None,
    min_confidence: float = 0.0,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[Signal], int]:
    query = select(Signal).where(Signal.status == SignalStatusEnum.active)

    if segment:
        query = query.where(Signal.segment == segment)
    if signal_type:
        query = query.where(Signal.signal_type == signal_type)
    if min_confidence > 0:
        query = query.where(Signal.confidence_score >= min_confidence)

    count_query = select(func.count()).select_from(query.subquery())
    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    query = query.order_by(desc(Signal.confidence_score), desc(Signal.created_at))
    query = query.limit(limit).offset(offset)

    result = await db.execute(query)
    signals = result.scalars().all()
    return list(signals), total


async def get_signals_history(
    db: AsyncSession,
    status: Optional[str] = None,
    segment: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[Signal], int]:
    query = select(Signal)
    if status and status != "all":
        query = query.where(Signal.status == status)
    if segment:
        query = query.where(Signal.segment == segment)

    count_query = select(func.count()).select_from(query.subquery())
    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    query = query.order_by(desc(Signal.created_at)).limit(limit).offset(offset)
    result = await db.execute(query)
    return list(result.scalars().all()), total


async def update_signal_status(
    signal_id: str,
    status: str,
    db: AsyncSession,
) -> Optional[Signal]:
    signal = await get_signal_by_id(signal_id, db)
    if signal:
        signal.status = status
        signal.updated_at = datetime.utcnow()
        await db.commit()
        await db.refresh(signal)
    return signal


async def get_signal_accuracy_stats(db: AsyncSession) -> dict:
    total_result = await db.execute(
        select(func.count(Signal.id)).where(Signal.status != SignalStatusEnum.active)
    )
    total = total_result.scalar() or 0

    win_result = await db.execute(
        select(func.count(Signal.id)).where(
            Signal.status.in_([SignalStatusEnum.target1_hit, SignalStatusEnum.target2_hit])
        )
    )
    wins = win_result.scalar() or 0

    loss_result = await db.execute(
        select(func.count(Signal.id)).where(Signal.status == SignalStatusEnum.sl_hit)
    )
    losses = loss_result.scalar() or 0

    expired_result = await db.execute(
        select(func.count(Signal.id)).where(Signal.status == SignalStatusEnum.expired)
    )
    expired = expired_result.scalar() or 0

    avg_conf_result = await db.execute(select(func.avg(Signal.confidence_score)))
    avg_conf = float(avg_conf_result.scalar() or 0)

    avg_rr_result = await db.execute(select(func.avg(Signal.risk_reward_ratio)))
    avg_rr = float(avg_rr_result.scalar() or 0)

    win_rate = round(wins / total * 100, 1) if total > 0 else 0.0

    return {
        "total_signals": total,
        "win_count": wins,
        "loss_count": losses,
        "expired_count": expired,
        "win_rate": win_rate,
        "avg_confidence": round(avg_conf, 1),
        "avg_rr_ratio": round(avg_rr, 2),
        "by_segment": {},
    }


async def expire_old_signals(db: AsyncSession) -> int:
    now = datetime.utcnow()
    result = await db.execute(
        select(Signal).where(
            and_(
                Signal.status == SignalStatusEnum.active,
                Signal.expires_at < now,
            )
        )
    )
    signals = result.scalars().all()
    count = 0
    for signal in signals:
        signal.status = SignalStatusEnum.expired
        count += 1

    if count > 0:
        await db.commit()
        logger.info(f"Expired {count} signals")
    return count
