from datetime import datetime
from typing import Optional
import uuid
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from app.models.portfolio import PortfolioSnapshot
from app.models.trade import PaperTrade, TradeStatusEnum
from app.models.user import User

logger = logging.getLogger(__name__)


async def get_portfolio_summary(user_id: str, db: AsyncSession) -> dict:
    user_result = await db.execute(select(User).where(User.id == user_id))
    user = user_result.scalar_one_or_none()
    if not user:
        return {}

    virtual_capital = float(user.virtual_capital)

    open_result = await db.execute(
        select(PaperTrade).where(
            and_(
                PaperTrade.user_id == user_id,
                PaperTrade.status.in_([TradeStatusEnum.open, TradeStatusEnum.target1_hit]),
            )
        )
    )
    open_trades = open_result.scalars().all()

    closed_result = await db.execute(
        select(PaperTrade).where(
            and_(
                PaperTrade.user_id == user_id,
                PaperTrade.status.in_([
                    TradeStatusEnum.closed,
                    TradeStatusEnum.target1_hit,
                    TradeStatusEnum.target2_hit,
                    TradeStatusEnum.sl_hit,
                ]),
                PaperTrade.exit_price.isnot(None),
            )
        )
    )
    closed_trades = closed_result.scalars().all()

    open_pnl = sum(float(t.pnl) for t in open_trades)
    closed_pnl = sum(float(t.pnl) for t in closed_trades if t.pnl)
    total_pnl = open_pnl + closed_pnl

    used_capital = sum(float(t.entry_price) * float(t.quantity) for t in open_trades)
    available_capital = virtual_capital - used_capital

    total_closed = len(closed_trades)
    wins = sum(1 for t in closed_trades if float(t.pnl or 0) > 0)
    win_rate = round(wins / total_closed * 100, 1) if total_closed > 0 else 0.0

    total_value = virtual_capital + total_pnl

    return {
        "virtual_capital": virtual_capital,
        "total_value": round(total_value, 2),
        "total_pnl": round(total_pnl, 2),
        "total_pnl_pct": round(total_pnl / virtual_capital * 100, 2) if virtual_capital > 0 else 0.0,
        "open_trades": len(open_trades),
        "closed_trades": total_closed,
        "win_rate": win_rate,
        "used_capital": round(used_capital, 2),
        "available_capital": round(available_capital, 2),
    }


async def take_portfolio_snapshot(user_id: str, db: AsyncSession) -> PortfolioSnapshot:
    summary = await get_portfolio_summary(user_id, db)

    snapshot = PortfolioSnapshot(
        id=str(uuid.uuid4()),
        user_id=user_id,
        total_value=summary.get("total_value", 0),
        total_pnl=summary.get("total_pnl", 0),
        total_pnl_pct=summary.get("total_pnl_pct", 0),
        open_trades=summary.get("open_trades", 0),
        snapshot_at=datetime.utcnow(),
    )
    db.add(snapshot)
    await db.commit()
    await db.refresh(snapshot)
    return snapshot


async def get_portfolio_chart(
    user_id: str,
    db: AsyncSession,
    limit: int = 100,
) -> list[PortfolioSnapshot]:
    result = await db.execute(
        select(PortfolioSnapshot)
        .where(PortfolioSnapshot.user_id == user_id)
        .order_by(PortfolioSnapshot.snapshot_at.desc())
        .limit(limit)
    )
    snapshots = result.scalars().all()
    return list(reversed(snapshots))


async def take_all_snapshots(db: AsyncSession):
    result = await db.execute(select(User.id).where(User.virtual_capital > 0))
    user_ids = [row[0] for row in result.all()]
    for user_id in user_ids:
        try:
            await take_portfolio_snapshot(user_id, db)
        except Exception as e:
            logger.error(f"Snapshot failed for user {user_id}: {e}")
