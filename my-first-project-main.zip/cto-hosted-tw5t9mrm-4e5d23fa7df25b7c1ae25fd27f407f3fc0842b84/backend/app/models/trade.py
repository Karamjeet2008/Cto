import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, Numeric, ForeignKey, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base
import enum


class TradeStatusEnum(str, enum.Enum):
    open = "open"
    closed = "closed"
    target1_hit = "target1_hit"
    target2_hit = "target2_hit"
    sl_hit = "sl_hit"


class PaperTrade(Base):
    __tablename__ = "paper_trades"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    signal_id: Mapped[str] = mapped_column(String(36), ForeignKey("signals.id"), nullable=False, index=True)
    quantity: Mapped[float] = mapped_column(Numeric(15, 4), nullable=False)
    entry_price: Mapped[float] = mapped_column(Numeric(15, 4), nullable=False)
    exit_price: Mapped[float | None] = mapped_column(Numeric(15, 4), nullable=True)
    current_price: Mapped[float] = mapped_column(Numeric(15, 4), nullable=False)
    pnl: Mapped[float] = mapped_column(Numeric(15, 4), default=0.0)
    pnl_pct: Mapped[float] = mapped_column(Numeric(8, 4), default=0.0)
    status: Mapped[str] = mapped_column(SAEnum(TradeStatusEnum), default=TradeStatusEnum.open)
    exit_reason: Mapped[str | None] = mapped_column(String(50), nullable=True)
    opened_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    user: Mapped["User"] = relationship("User", back_populates="trades")
    signal: Mapped["Signal"] = relationship("Signal", back_populates="trades")
