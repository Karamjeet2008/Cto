import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, Numeric, Integer, Text, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base
import enum


class SegmentEnum(str, enum.Enum):
    equity = "equity"
    fo = "fo"
    commodity = "commodity"
    currency = "currency"


class SignalTypeEnum(str, enum.Enum):
    BUY = "BUY"
    SELL = "SELL"


class SignalStatusEnum(str, enum.Enum):
    active = "active"
    target1_hit = "target1_hit"
    target2_hit = "target2_hit"
    sl_hit = "sl_hit"
    expired = "expired"


class OutcomeEnum(str, enum.Enum):
    win_t1 = "win_t1"
    win_t2 = "win_t2"
    loss = "loss"
    expired = "expired"


class Signal(Base):
    __tablename__ = "signals"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    instrument: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    display_name: Mapped[str] = mapped_column(String(100), nullable=False)
    segment: Mapped[str] = mapped_column(SAEnum(SegmentEnum), nullable=False)
    signal_type: Mapped[str] = mapped_column(SAEnum(SignalTypeEnum), nullable=False)
    entry_price: Mapped[float] = mapped_column(Numeric(15, 4), nullable=False)
    stop_loss: Mapped[float] = mapped_column(Numeric(15, 4), nullable=False)
    target1: Mapped[float] = mapped_column(Numeric(15, 4), nullable=False)
    target2: Mapped[float] = mapped_column(Numeric(15, 4), nullable=False)
    confidence_score: Mapped[float] = mapped_column(Numeric(5, 2), nullable=False)
    risk_reward_ratio: Mapped[float] = mapped_column(Numeric(5, 2), nullable=False)
    ai_reasoning: Mapped[str] = mapped_column(Text, nullable=True)
    technical_score: Mapped[float] = mapped_column(Numeric(5, 2), default=0.0)
    sentiment_score: Mapped[float] = mapped_column(Numeric(5, 2), default=0.0)
    quant_score: Mapped[float] = mapped_column(Numeric(5, 2), default=0.0)
    options_score: Mapped[float] = mapped_column(Numeric(5, 2), default=0.0)
    status: Mapped[str] = mapped_column(SAEnum(SignalStatusEnum), default=SignalStatusEnum.active)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    backtest_win_rate: Mapped[float] = mapped_column(Numeric(5, 2), default=0.0)
    backtest_sample_size: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    trades: Mapped[list["PaperTrade"]] = relationship("PaperTrade", back_populates="signal", lazy="select")
    outcomes: Mapped[list["SignalOutcome"]] = relationship("SignalOutcome", back_populates="signal", lazy="select")


class SignalOutcome(Base):
    __tablename__ = "signal_outcomes"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    signal_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    outcome: Mapped[str] = mapped_column(SAEnum(OutcomeEnum), nullable=False)
    actual_exit_price: Mapped[float | None] = mapped_column(Numeric(15, 4), nullable=True)
    pnl_pct: Mapped[float | None] = mapped_column(Numeric(8, 4), nullable=True)
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    signal: Mapped["Signal"] = relationship("Signal", back_populates="outcomes")
