import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, Numeric, Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base


class PortfolioSnapshot(Base):
    __tablename__ = "portfolio_snapshots"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    total_value: Mapped[float] = mapped_column(Numeric(15, 2), nullable=False)
    total_pnl: Mapped[float] = mapped_column(Numeric(15, 2), default=0.0)
    total_pnl_pct: Mapped[float] = mapped_column(Numeric(8, 4), default=0.0)
    open_trades: Mapped[int] = mapped_column(Integer, default=0)
    snapshot_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    user: Mapped["User"] = relationship("User", back_populates="portfolio_snapshots")
