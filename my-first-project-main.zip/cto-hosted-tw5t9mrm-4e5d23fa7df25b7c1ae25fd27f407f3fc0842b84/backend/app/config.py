from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+asyncpg://signal_user:signal_pass@localhost:5432/signal_db"
    REDIS_URL: str = "redis://localhost:6379"
    SECRET_KEY: str = "3f8c2a1d9e7b4f6a0c5e8d2b7a3f9e1c4d8b6a2f5e0c7d9b3a6f8e1c4d7b0a2"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    GOOGLE_CLIENT_ID: str = ""
    GOOGLE_CLIENT_SECRET: str = ""
    ENVIRONMENT: str = "development"
    SIGNAL_ENGINE_INTERVAL_MINUTES: int = 15
    MIN_CONFIDENCE_THRESHOLD: float = 55.0
    KOTAK_NEO_API_KEY: str = ""
    KOTAK_NEO_SECRET: str = ""
    KOTAK_NEO_ACCESS_TOKEN: str = ""
    ALLOWED_ORIGINS: str = "http://localhost:3000"

    class Config:
        env_file = ".env"
        extra = "ignore"

    @property
    def allowed_origins_list(self) -> list[str]:
        return [o.strip() for o in self.ALLOWED_ORIGINS.split(",")]


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
