"""
Seed script: creates demo signals for testing the UI.
Run: cd backend && python scripts/seed.py
"""
import asyncio
import sys
import os
import uuid
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import AsyncSessionLocal, create_tables
from app.models.signal import Signal, SignalStatusEnum


DEMO_SIGNALS = [
    {
        "instrument": "RELIANCE.NS",
        "display_name": "Reliance Industries",
        "segment": "equity",
        "signal_type": "BUY",
        "entry_price": 2840.50,
        "stop_loss": 2790.00,
        "target1": 2910.00,
        "target2": 2980.00,
        "confidence_score": 82.5,
        "risk_reward_ratio": 1.37,
        "ai_reasoning": "Technical indicators are strongly bullish (TA score: +75) • Quantitative models confirm upward momentum (score: +65) • Market sentiment from recent news is positive (score: +45) • Key support at ₹2,790.00 • Key resistance at ₹2,980.00",
        "technical_score": 75.0,
        "sentiment_score": 45.0,
        "quant_score": 65.0,
        "options_score": 0.0,
        "backtest_win_rate": 68.5,
        "backtest_sample_size": 54,
        "expires_at": datetime.utcnow() + timedelta(days=4),
    },
    {
        "instrument": "^NSEI",
        "display_name": "Nifty 50",
        "segment": "fo",
        "signal_type": "BUY",
        "entry_price": 22450.00,
        "stop_loss": 22200.00,
        "target1": 22750.00,
        "target2": 23050.00,
        "confidence_score": 78.3,
        "risk_reward_ratio": 1.20,
        "ai_reasoning": "Technical indicators are moderately bullish (TA score: +60) • Options flow (PCR analysis) suggests buying pressure • Quantitative models confirm upward momentum (score: +55) • Key support at ₹22,200.00",
        "technical_score": 60.0,
        "sentiment_score": 30.0,
        "quant_score": 55.0,
        "options_score": 70.0,
        "backtest_win_rate": 71.2,
        "backtest_sample_size": 67,
        "expires_at": datetime.utcnow() + timedelta(hours=6),
    },
    {
        "instrument": "TCS.NS",
        "display_name": "TCS",
        "segment": "equity",
        "signal_type": "SELL",
        "entry_price": 3980.00,
        "stop_loss": 4080.00,
        "target1": 3850.00,
        "target2": 3720.00,
        "confidence_score": 71.8,
        "risk_reward_ratio": 1.30,
        "ai_reasoning": "Technical indicators are moderately bearish (TA score: -55) • Quantitative models confirm downward momentum (score: -48) • Key resistance at ₹4,080.00",
        "technical_score": -55.0,
        "sentiment_score": -25.0,
        "quant_score": -48.0,
        "options_score": 0.0,
        "backtest_win_rate": 62.0,
        "backtest_sample_size": 42,
        "expires_at": datetime.utcnow() + timedelta(days=3),
    },
    {
        "instrument": "GC=F",
        "display_name": "Gold",
        "segment": "commodity",
        "signal_type": "BUY",
        "entry_price": 2645.00,
        "stop_loss": 2610.00,
        "target1": 2690.00,
        "target2": 2740.00,
        "confidence_score": 75.6,
        "risk_reward_ratio": 1.29,
        "ai_reasoning": "Technical indicators are strongly bullish (TA score: +70) • Market sentiment from recent news is positive (score: +55) • Key support at ₹2,610.00",
        "technical_score": 70.0,
        "sentiment_score": 55.0,
        "quant_score": 60.0,
        "options_score": 0.0,
        "backtest_win_rate": 65.0,
        "backtest_sample_size": 38,
        "expires_at": datetime.utcnow() + timedelta(days=5),
    },
    {
        "instrument": "USDINR=X",
        "display_name": "USD/INR",
        "segment": "currency",
        "signal_type": "SELL",
        "entry_price": 84.25,
        "stop_loss": 84.65,
        "target1": 83.85,
        "target2": 83.40,
        "confidence_score": 67.2,
        "risk_reward_ratio": 1.00,
        "ai_reasoning": "Technical indicators are moderately bearish (TA score: -50) • Market sentiment suggests rupee strength • Key resistance at ₹84.65",
        "technical_score": -50.0,
        "sentiment_score": -35.0,
        "quant_score": -40.0,
        "options_score": 0.0,
        "backtest_win_rate": 58.5,
        "backtest_sample_size": 31,
        "expires_at": datetime.utcnow() + timedelta(days=3),
    },
    {
        "instrument": "HDFCBANK.NS",
        "display_name": "HDFC Bank",
        "segment": "equity",
        "signal_type": "BUY",
        "entry_price": 1720.00,
        "stop_loss": 1685.00,
        "target1": 1765.00,
        "target2": 1815.00,
        "confidence_score": 80.1,
        "risk_reward_ratio": 1.29,
        "ai_reasoning": "Technical indicators are strongly bullish (TA score: +72) • Quantitative models confirm upward momentum • Market sentiment from recent news is positive • Key support at ₹1,685.00",
        "technical_score": 72.0,
        "sentiment_score": 50.0,
        "quant_score": 63.0,
        "options_score": 0.0,
        "backtest_win_rate": 70.0,
        "backtest_sample_size": 47,
        "expires_at": datetime.utcnow() + timedelta(days=4),
    },
    {
        "instrument": "CL=F",
        "display_name": "Crude Oil",
        "segment": "commodity",
        "signal_type": "SELL",
        "entry_price": 77.80,
        "stop_loss": 79.50,
        "target1": 75.90,
        "target2": 73.80,
        "confidence_score": 69.4,
        "risk_reward_ratio": 1.12,
        "ai_reasoning": "Technical indicators are bearish (TA score: -58) • Global demand concerns weighing on oil prices • Key resistance at ₹79.50",
        "technical_score": -58.0,
        "sentiment_score": -40.0,
        "quant_score": -45.0,
        "options_score": 0.0,
        "backtest_win_rate": 60.0,
        "backtest_sample_size": 35,
        "expires_at": datetime.utcnow() + timedelta(days=5),
    },
    {
        "instrument": "^NSEBANK",
        "display_name": "Bank Nifty",
        "segment": "fo",
        "signal_type": "SELL",
        "entry_price": 47800.00,
        "stop_loss": 48400.00,
        "target1": 47100.00,
        "target2": 46400.00,
        "confidence_score": 73.5,
        "risk_reward_ratio": 1.17,
        "ai_reasoning": "Technical indicators are bearish (TA score: -62) • Options flow shows heavy call writing at 48000 • Quantitative models confirm downward momentum • Key resistance at ₹48,400.00",
        "technical_score": -62.0,
        "sentiment_score": -20.0,
        "quant_score": -52.0,
        "options_score": -68.0,
        "backtest_win_rate": 66.7,
        "backtest_sample_size": 48,
        "expires_at": datetime.utcnow() + timedelta(hours=6),
    },
]


async def seed():
    print("Creating tables...")
    await create_tables()

    async with AsyncSessionLocal() as db:
        from sqlalchemy import select, func
        result = await db.execute(select(func.count(Signal.id)))
        count = result.scalar()

        if count > 0:
            print(f"Database already has {count} signals. Skipping seed.")
            return

        print(f"Seeding {len(DEMO_SIGNALS)} demo signals...")
        for sig_data in DEMO_SIGNALS:
            signal = Signal(
                id=str(uuid.uuid4()),
                **sig_data,
                status="active",
                updated_at=datetime.utcnow(),
                created_at=datetime.utcnow(),
            )
            db.add(signal)

        await db.commit()
        print(f"✅ Seeded {len(DEMO_SIGNALS)} signals successfully!")


if __name__ == "__main__":
    asyncio.run(seed())
