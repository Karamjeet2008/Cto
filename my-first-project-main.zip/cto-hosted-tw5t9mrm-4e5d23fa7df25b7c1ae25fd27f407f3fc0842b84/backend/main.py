import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.database import create_tables, dispose_engine
from app.redis_client import get_redis, close_redis
from app.routers import auth, signals, trades, portfolio, market, ws
from app.scheduler import setup_scheduler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting Signal Engine API...")
    await create_tables()
    logger.info("Database tables ready")

    await get_redis()

    scheduler = setup_scheduler(run_on_start=False)
    scheduler.start()
    logger.info("Scheduler started")

    yield

    scheduler.shutdown(wait=False)
    await close_redis()
    await dispose_engine()
    logger.info("Shutdown complete")


app = FastAPI(
    title="AI Signal Engine API",
    description="Production-grade AI-driven Indian share market signal generation API",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(signals.router)
app.include_router(trades.router)
app.include_router(portfolio.router)
app.include_router(market.router)
app.include_router(ws.router)


@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}


@app.get("/")
async def root():
    return {"message": "AI Signal Engine API", "docs": "/docs"}
