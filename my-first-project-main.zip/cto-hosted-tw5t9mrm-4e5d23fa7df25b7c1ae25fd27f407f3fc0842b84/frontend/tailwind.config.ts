import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: {
          DEFAULT: "#0a0a0f",
          secondary: "#0f0f1a",
          card: "#13131f",
        },
        border: {
          DEFAULT: "#1e1e2e",
          accent: "#2a2a3e",
        },
        buy: {
          DEFAULT: "#00d4aa",
          muted: "rgba(0,212,170,0.12)",
          glow: "rgba(0,212,170,0.3)",
        },
        sell: {
          DEFAULT: "#ff4444",
          muted: "rgba(255,68,68,0.12)",
          glow: "rgba(255,68,68,0.3)",
        },
        accent: {
          DEFAULT: "#6366f1",
          muted: "rgba(99,102,241,0.12)",
        },
        profit: "#00d4aa",
        loss: "#ff4444",
        warning: "#f59e0b",
        "text-primary": "#e2e8f0",
        "text-secondary": "#94a3b8",
        "text-muted": "#64748b",
      },
      fontFamily: {
        mono: ["JetBrains Mono", "Fira Code", "Consolas", "monospace"],
      },
      boxShadow: {
        "buy-glow": "0 0 20px rgba(0,212,170,0.15), 0 0 40px rgba(0,212,170,0.05)",
        "sell-glow": "0 0 20px rgba(255,68,68,0.15), 0 0 40px rgba(255,68,68,0.05)",
        card: "0 4px 6px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.03)",
      },
    },
  },
  plugins: [],
};
export default config;
