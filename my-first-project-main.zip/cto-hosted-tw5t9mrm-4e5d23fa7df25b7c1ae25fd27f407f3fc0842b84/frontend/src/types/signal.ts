export interface Signal {
  id: string;
  instrument: string;
  display_name: string;
  segment: "equity" | "fo" | "commodity" | "currency";
  signal_type: "BUY" | "SELL";
  entry_price: number;
  stop_loss: number;
  target1: number;
  target2: number;
  confidence_score: number;
  risk_reward_ratio: number;
  ai_reasoning: string;
  technical_score: number;
  sentiment_score: number;
  quant_score: number;
  options_score: number;
  status: "active" | "target1_hit" | "target2_hit" | "sl_hit" | "expired";
  expires_at: string | null;
  backtest_win_rate: number;
  backtest_sample_size: number;
  created_at: string;
  updated_at: string;
}

export interface SignalListResponse {
  signals: Signal[];
  total: number;
  active_count: number;
}

export interface SignalAccuracyStats {
  total_signals: number;
  win_count: number;
  loss_count: number;
  expired_count: number;
  win_rate: number;
  avg_confidence: number;
  avg_rr_ratio: number;
}
